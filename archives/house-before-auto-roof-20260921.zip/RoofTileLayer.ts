const {regClass}=Laya;

/** A normal TileMapLayer above the walls. Also protects editor tile serialization. */
@regClass('3591ef95-3f88-4957-88b2-bb349b43fcb1')
@Laya.runInEditor
export class RoofTileLayer extends Laya.Script {
    onEnable(): void { (this.owner as Laya.Sprite).zOrder=100000; this.protect(); }
    onUpdate(): void { if (!Laya.LayaEnv.isPlaying) this.protect(); }
    private protect(): void {
        const layer=this.owner.getComponent(Laya.TileMapLayer);
        const chunks=layer && (layer as any)._chunkDatas;
        if (!chunks) return;
        for(const row of Object.values(chunks))for(const item of Object.values(row)){
            const chunk=item as any;
            if(!chunk._cellDataRefMap||!chunk._refGids)continue;
            const repair=()=>{const gids=Object.keys(chunk._cellDataRefMap).filter(k=>chunk._cellDataRefMap[k]?.length>0).map(Number);chunk._refGids.splice(0,chunk._refGids.length,...gids);};
            repair();
            if(Object.prototype.hasOwnProperty.call(chunk,'compressData'))continue;
            const descriptor=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(chunk),'compressData');
            if(!descriptor?.get||!descriptor.set)continue;
            Object.defineProperty(chunk,'compressData',{configurable:true,get:()=>{repair();return descriptor.get.call(chunk);},set:value=>descriptor.set.call(chunk,value)});
        }
    }
}
