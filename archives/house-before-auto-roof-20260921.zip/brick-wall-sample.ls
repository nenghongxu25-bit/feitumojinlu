{
  "_$ver": 1,
  "_$id": "brickwallsample",
  "_$type": "Scene",
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "name": "BrickWallSampleReady",
  "width": 1334,
  "height": 750,
  "_$comp": [
    {
      "_$type": "86fb35d4-bffe-4012-bc9f-85f003b0b723",
      "scriptPath": "../src/systems/IsometricStudyBackdrop.ts"
    }
  ],
  "_$child": [
    {
      "_$id": "brickworld",
      "_$type": "Sprite",
      "name": "ActorLayer",
      "x": 667,
      "y": 260,
      "width": 0,
      "height": 0,
      "scaleX": 0.5,
      "scaleY": 0.5,
      "_$child": [
        {
          "_$id": "7a874a38f884",
          "_$type": "Sprite",
          "name": "BrickWallLayer",
          "width": 0,
          "height": 0,
          "_$comp": [
            {
              "_$type": "TileMapLayer",
              "layer": 0,
              "tileSet": {
                "_$uuid": "045e4ac5-bdbc-4d01-a4fa-1a374b73cec6",
                "_$type": "TileSet"
              },
              "chunkDatas": {
                "0": {
                  "0": {
                    "_$type": "TileMapChunkData",
                    "chunkX": 0,
                    "chunkY": 0,
                    "compressData": {
                      "5": [
                        161,
                        194,
                        129,
                        96,
                        64
                      ],
                      "6": [
                        226
                      ],
                      "10": [
                        258,
                        289,
                        352
                      ],
                      "12": [
                        384
                      ],
                      "65537": [
                        321
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "64": 0,
                      "96": 0,
                      "129": 0,
                      "161": 0,
                      "194": 0,
                      "226": 0,
                      "258": 0,
                      "289": 0,
                      "321": 0,
                      "352": 0,
                      "384": 0,
                      "_$type": "Record"
                    }
                  },
                  "_$type": "Record",
                  "-1": {
                    "_$type": "TileMapChunkData",
                    "chunkX": -1,
                    "chunkY": 0,
                    "compressData": {
                      "3": [
                        63
                      ],
                      "5": [
                        253,
                        286,
                        351,
                        383,
                        445,
                        478
                      ],
                      "9": [
                        221
                      ],
                      "10": [
                        95,
                        126,
                        158,
                        189
                      ],
                      "65536": [
                        318
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "63": 0,
                      "95": 0,
                      "126": 0,
                      "158": 0,
                      "189": 0,
                      "221": 0,
                      "253": 0,
                      "286": 0,
                      "318": 0,
                      "351": 0,
                      "383": 0,
                      "445": 0,
                      "478": 0,
                      "_$type": "Record"
                    }
                  }
                },
                "_$type": "Record",
                "-1": {
                  "0": {
                    "_$type": "TileMapChunkData",
                    "chunkX": 0,
                    "chunkY": -1,
                    "compressData": {
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "_$type": "Record"
                    }
                  },
                  "_$type": "Record"
                }
              }
            },
            {
              "_$type": "818f8acf-a35f-42d4-b285-b2d8b67d5af8",
              "scriptPath": "../src/systems/BrickWallTileLayer.ts",
              "actorLayer": null
            }
          ]
        },
        {
          "_$id": "brickactor",
          "_$type": "Sprite",
          "name": "WalkHere",
          "x": -96,
          "y": 416,
          "width": 0,
          "height": 0,
          "_$comp": [
            {
              "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
              "scriptPath": "../src/systems/DepthSortable.ts",
              "groundY": 0,
              "blendDistance": 0
            },
            {
              "_$type": "f46d1f31-2b7f-4f2f-88bb-64a6e40a1f51",
              "scriptPath": "../src/systems/BrickWallWalkthrough.ts"
            }
          ],
          "_$child": [
            {
              "_$id": "b1t7v9q2",
              "_$type": "Sprite",
              "name": "viewnode",
              "y": -80,
              "width": 0,
              "height": 0,
              "anchorX": 0.5,
              "anchorY": 0.5,
              "_$comp": [
                {
                  "_$type": "Spine2DRenderNode",
                  "layer": 0,
                  "useFastRender": false,
                  "source": "res://f87ec402-9dd0-4a49-90f0-2352581455dc",
                  "skinName": "player_normal",
                  "animationName": "idle/idle_ranged_firearm",
                  "externalSkins": [
                    {
                      "_$type": "ExternalSkin"
                    }
                  ],
                  "offset": {
                    "_$type": "Vector2",
                    "x": -80,
                    "y": -120
                  },
                  "premultipliedAlpha": true
                }
              ]
            }
          ]
        },
        {
          "_$id": "slaterooflayer",
          "_$type": "Sprite",
          "name": "RoofLayer",
          "width": 0,
          "height": 0,
          "_$comp": [
            {
              "_$type": "TileMapLayer",
              "layer": 0,
              "tileSet": {
                "_$uuid": "810ce2b9-719c-4c25-890a-f650da8741b4",
                "_$type": "TileSet"
              },
              "chunkDatas": {
                "0": {
                  "0": {
                    "_$type": "TileMapChunkData",
                    "chunkX": 0,
                    "chunkY": 0,
                    "compressData": {
                      "0": [
                        32,
                        65,
                        97,
                        130,
                        162
                      ],
                      "1": [
                        64,
                        96,
                        129,
                        161,
                        194
                      ],
                      "2": [
                        128,
                        160,
                        193,
                        225
                      ],
                      "3": [
                        192,
                        224,
                        257
                      ],
                      "4": [
                        256,
                        288
                      ],
                      "5": [
                        320
                      ],
                      "7": [
                        0
                      ],
                      "14": [
                        195
                      ],
                      "15": [
                        226
                      ],
                      "16": [
                        258
                      ],
                      "17": [
                        289
                      ],
                      "18": [
                        321
                      ],
                      "19": [
                        352
                      ],
                      "20": [
                        384
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "0": 0,
                      "32": 0,
                      "64": 0,
                      "65": 0,
                      "96": 0,
                      "97": 0,
                      "128": 0,
                      "129": 0,
                      "130": 0,
                      "160": 0,
                      "161": 0,
                      "162": 0,
                      "192": 0,
                      "193": 0,
                      "194": 0,
                      "195": 0,
                      "224": 0,
                      "225": 0,
                      "226": 0,
                      "256": 0,
                      "257": 0,
                      "258": 0,
                      "288": 0,
                      "289": 0,
                      "320": 0,
                      "321": 0,
                      "352": 0,
                      "384": 0,
                      "_$type": "Record"
                    }
                  },
                  "_$type": "Record",
                  "-1": {
                    "_$type": "TileMapChunkData",
                    "chunkX": -1,
                    "chunkY": 0,
                    "compressData": {
                      "2": [
                        127
                      ],
                      "3": [
                        159,
                        191
                      ],
                      "4": [
                        190,
                        223,
                        255
                      ],
                      "5": [
                        222,
                        254,
                        287,
                        319
                      ],
                      "6": [
                        253,
                        286,
                        318,
                        351,
                        383
                      ],
                      "8": [
                        63
                      ],
                      "9": [
                        95
                      ],
                      "10": [
                        126
                      ],
                      "11": [
                        158
                      ],
                      "12": [
                        189
                      ],
                      "13": [
                        221
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "63": 0,
                      "95": 0,
                      "126": 0,
                      "127": 0,
                      "158": 0,
                      "159": 0,
                      "189": 0,
                      "190": 0,
                      "191": 0,
                      "221": 0,
                      "222": 0,
                      "223": 0,
                      "253": 0,
                      "254": 0,
                      "255": 0,
                      "286": 0,
                      "287": 0,
                      "318": 0,
                      "319": 0,
                      "351": 0,
                      "383": 0,
                      "_$type": "Record"
                    }
                  }
                },
                "_$type": "Record"
              }
            },
            {
              "_$type": "3591ef95-3f88-4957-88b2-bb349b43fcb1",
              "scriptPath": "../src/systems/RoofTileLayer.ts"
            }
          ]
        }
      ]
    }
  ]
}