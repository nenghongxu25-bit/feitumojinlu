import { DepthObstacle } from './DepthObstacle';
import { wallFootprints, wallGroundAtX } from './BrickWallGeometry';
const { regClass, property } = Laya;

/** Paint real tiles in the editor; expand them for actor interleaving at runtime. */
@regClass('818f8acf-a35f-42d4-b285-b2d8b67d5af8')
@Laya.runInEditor
export class BrickWallTileLayer extends Laya.Script {
    @property({ type: Laya.Sprite, caption: '人物所在层（空则自动查找ActorLayer）' })
    public actorLayer: Laya.Sprite | null = null;
    private pieces: Laya.Sprite[] = [];
    private textures: Laya.Texture[] = [];
    private renderer: Laya.TileMapLayer | null = null;
    private started = false;
    private originalEnabled = true;

    onStart(): void { if (!Laya.LayaEnv.isPlaying) return; this.started = true; this.rebuild(); }
    onEnable(): void { this.protectPaintedCells(); if (Laya.LayaEnv.isPlaying && this.started) this.rebuild(); }
    onUpdate(): void { if (!Laya.LayaEnv.isPlaying) this.protectPaintedCells(); }
    onDisable(): void { this.clear(); }
    onDestroy(): void { this.clear(); }

    /** Engine _setCell removes the new gid from _refGids when replacing the
     * last cell of the old gid. Keep serialization based on the actual cells.
     * Scoped to this wall layer; never changes the editor's global prototypes. */
    private protectPaintedCells(): void {
        const layer = this.owner.getComponent(Laya.TileMapLayer);
        const chunks = layer && (layer as any)._chunkDatas;
        if (!chunks) return;
        for (const row of Object.values(chunks)) for (const chunk of Object.values(row)) {
            const data = chunk as any;
            if (!data._cellDataRefMap || !data._refGids) continue;
            const repair = () => {
                const gids = Object.keys(data._cellDataRefMap)
                    .filter(key => data._cellDataRefMap[key]?.length > 0).map(Number);
                data._refGids.splice(0, data._refGids.length, ...gids);
            };
            repair();
            if (Object.prototype.hasOwnProperty.call(data, 'compressData')) continue;
            const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(data), 'compressData');
            if (!descriptor?.get || !descriptor.set) continue;
            Object.defineProperty(data, 'compressData', {
                configurable: true,
                get: () => { repair(); return descriptor.get.call(data); },
                set: value => descriptor.set.call(data, value)
            });
        }
    }

    private find(root: Laya.Node): Laya.Sprite | null {
        if (root.name === 'ActorLayer') return root as Laya.Sprite;
        for (const child of root.children) { const found = this.find(child); if (found) return found; }
        return null;
    }

    /** Call after runtime tile edits; normal editor painting rebuilds on Play. */
    public rebuild(): void {
        if (!Laya.LayaEnv.isPlaying) return;
        this.protectPaintedCells();
        this.clear();
        const owner = this.owner as Laya.Sprite;
        const target = this.actorLayer || (owner.scene && this.find(owner.scene));
        const layer = owner.getComponent(Laya.TileMapLayer);
        if (!target || !layer?.tileSet) { console.error('[BrickWallTileLayer] Missing ActorLayer or TileSet.'); return; }
        // This engine has no public cell iterator. Read its chunk table, then use public
        // chunk accessors; screen bounds are unreliable for overhanging tall tiles.
        const chunks = (layer as any)._chunkDatas as Record<string, Record<string, Laya.TileMapChunkData>>;
        if (!chunks) { console.error('[BrickWallTileLayer] Unsupported engine chunk layout.'); return; }
        const map = (x: number, y: number): Laya.Point => target.globalToLocal(owner.localToGlobal(new Laya.Point(x,y), false), false);
        const origin = map(0,0), ax = map(1,0), ay = map(0,1);
        const a=ax.x-origin.x,b=ax.y-origin.y,c=ay.x-origin.x,d=ay.y-origin.y;
        // Rotating the whole wall layer would invalidate screen-space vertical sorting.
        if (Math.abs(b)>1e-5 || Math.abs(c)>1e-5 || a<=0 || d<=0) { console.error('[BrickWallTileLayer] Keep wall layer axes unrotated and scales positive.'); return; }
        let count = 0;
        const center = new Laya.Vector2();
        const cells: {x:number;y:number;info:Laya.ChunkCellInfo}[]=[];
        for(const row of Object.values(chunks))for(const chunk of Object.values(row)){
            for(const indices of Object.values(chunk.compressData))for(const index of indices){
                const size=layer.renderTileSize;
                cells.push({x:chunk.chunkX*size+index%size,y:chunk.chunkY*size+Math.floor(index/size),info:chunk.getCell(index)});
            }
        }
        for (const {x,y,info} of cells) {
            if (!info?.cell) continue;
            const cell=info.cell, alt=cell.cellowner, group=alt.owner;
            const mask=alt.localPos.y*4+alt.localPos.x;
            if (mask<0 || mask>15 || info._transFlag || cell.transFlag) {
                console.error('[BrickWallTileLayer] Use the supplied direction tiles without rotate/flip.'); continue;
            }
            layer.gridToPixel(x,y,center);
            const texture=new Laya.Texture(group.atlas); this.textures.push(texture);
            const atlasX=2+alt.localPos.x*260,atlasY=2+alt.localPos.y*388;
            // Thin strips sort by their own ground intersection, not the whole wall's midpoint.
            for(let sx=0;sx<256;sx+=4){
                const ground=wallGroundAtX(mask,sx+2-128);
                if(ground===null)continue;
                const cut=Laya.Texture.createFromTexture(texture,atlasX+sx,atlasY,4,384); this.textures.push(cut);
                const node=new Laya.Sprite(); node.name='BrickWallVisual'; node.texture=cut; node.size(4,384);
                const pos=map(center.x+sx-128,center.y-336);
                target.addChild(node);node.pos(pos.x,pos.y);node.scale(a,d);
                node.zOrder=map(center.x+sx-126,center.y+ground).y;
                node.visible=owner.visible;node.alpha=owner.alpha; this.pieces.push(node);
            }
            for(const [u,v,w,h] of wallFootprints(mask)){
                const node=new Laya.Sprite();node.name='BrickWallFootprint';target.addChild(node);
                const p=map(center.x,center.y);
                node.transform=new Laya.Matrix(128*a,64*d,-128*a,64*d,p.x,p.y);
                const obstacle=node.addComponent(DepthObstacle);
                obstacle.blockX=u;obstacle.blockY=v;obstacle.blockWidth=w;obstacle.blockHeight=h;
                this.pieces.push(node);
            }
            count++;
        }
        this.renderer=layer;this.originalEnabled=layer.enabled;layer.enabled=false;
        console.info(`[BrickWallTileLayer] ${count} painted cells, ${this.pieces.length} render/collision pieces, height=256.`);
    }

    private clear(): void {
        for (const node of this.pieces) if(!node.destroyed) node.destroy(true);
        this.pieces.length=0;
        for (let i=this.textures.length-1;i>=0;i--) this.textures[i].destroy();
        this.textures.length=0;
        if(this.renderer && !this.renderer.destroyed) this.renderer.enabled=this.originalEnabled;
        this.renderer=null;
    }
}
