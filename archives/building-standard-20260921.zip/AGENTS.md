# AGENTS.md

## 建筑瓦片制作标准（用户确认，2026-09-21）

- 后续墙壁、室内地板、屋顶均以当前 `assets/tileset/brick-wall-v1/brick-wall-sample.ls` 为已验收标准，只替换纹理。
- 必须保持等距角度、几何轮廓、厚度、高度、网格、切片、锚点、拼接编号、碰撞和显隐行为一致；不要为不同材质另写一套规则。
- 房屋墙体与屋顶共用室内状态：室外墙实心；室内屋顶隐藏，挡住可见室内区域的墙半透明，不再用玩家脚底Y排除侧面前墙。实墙仍阻挡移动和目标视线。
- 制作前阅读 `docs/building-tiles-standard.md`；以此文档及验收快照为准，不按旧 README 的历史阶段描述回退。

## Laya 项目约束

- 只要问题涉及 LayaAir 项目、运行时行为、场景树、UI 绑定、Prefab、组件、渲染、相机、输入、动画、资源加载或日志排查，必须优先使用 MCP 读取运行时状态、日志和节点信息。
- 禁止只靠文件检索、静态 grep、猜测代码行为来下结论。
- 在回答 Laya 相关问题前，必须先验证运行时事实；如果 MCP 不可用，必须明确说明不可用，再退回到本地文件检查。
- 对于“为什么画面和代码不一致”“为什么编译后行为变了”“为什么节点/visible/层级不符合预期”这类问题，必须优先查 MCP，而不是只看源码。
- 如果已经通过 MCP 得到运行时证据，回答时要基于证据说明原因，不要用推测代替验证。


- Do not generate any UI in code without explicit user permission; use existing scene/prefab nodes and the placeholder image asset instead of drawRect/drawCircle fallbacks.

## 双材质地形图集制作约定

- 用户指定：今后制作双材质交接地块，默认沿用 `assets/tileset/forest-kit-v3/grass-dirt.png` 的双向九宫格形状模式：圆润转角，边界可有细碎自然起伏，切片接口固定。
- 形状参考与材质纹理分开。调整已有地块时，保留其现有纹理与配色，不擅自替换成参考图的材质。
- 修改已有图集前先备份；保持图片尺寸、格子位置、材质对应关系、UUID 和切片配置，除非用户明确要求重排。
- 细则见 `docs/terrain-transition-standard.md`。双向九宫格不自动等于完整自动地形系统；扩展凹角、分叉或三材质交汇时单独验证。
