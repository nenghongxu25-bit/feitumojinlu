const fs=require('fs'),vm=require('vm'),assert=require('assert'),ts=require('typescript');
const Laya={Script:class{},Point:class{constructor(x,y){this.x=x;this.y=y;}},regClass:()=>()=>{},property:()=>()=>{},runInEditor:()=>{},LayaEnv:{isPlaying:true},timer:{delta:100}};
function load(p,require=()=>({})){const c={exports:{},require,Laya};vm.runInNewContext(ts.transpileModule(fs.readFileSync(p,'utf8'),{compilerOptions:{module:1,target:4,experimentalDecorators:true}}).outputText,c);return c.exports;}
const geometry=load('src/systems/BrickWallGeometry.ts');
const vision=load('src/systems/WallVisionGeometry.ts',()=>geometry);
const interior=load('src/systems/HouseInteriorState.ts');
const {BrickWallTileLayer:Wall}=load('src/systems/BrickWallTileLayer.ts',p=>p.includes('HouseInteriorState')?interior:p.includes('WallVision')?vision:p.includes('Geometry')?geometry:{});
for(const mask of [5,10])for(const scale of [.5,1,2]){
 const wall={mask,x:200,y:300,a:scale*1.2,d:scale*.8};
 const p=(u,v)=>[200+128*(u-v)*wall.a,300+64*(u+v)*wall.d];
 const a=mask===5?p(0,-1):p(-1,0),b=mask===5?p(0,1):p(1,0);
 assert(vision.wallBlocksSight(wall,...a,...b),'both diagonal faces block sight under scaling');
 assert(vision.wallBlocksSight(wall,...b,...a),'sight is symmetric');
 assert(!vision.wallBlocksSight({...wall,mask:mask===5?16:17},...a,...b),'opening admits sight');
 assert(!vision.wallBlocksSight(wall,...a,...a),'same-point visibility');
}
const scene=JSON.parse(fs.readFileSync('assets/tileset/brick-wall-v1/brick-wall-sample.ls','utf8'));
const house=scene._$child[0]._$child[0],wallNode=house._$child.find(n=>n.name==='BrickWallLayer');
const chunks=wallNode._$comp[0].chunkDatas,parent={localToGlobal:p=>p,globalToLocal:p=>p};
const layer=new Wall();layer.target=parent;layer.surfaces=[];
for(const row of Object.values(chunks))for(const ch of Object.values(row))if(ch?.compressData)for(const [mask,indices]of Object.entries(ch.compressData))if(Array.isArray(indices))for(const i of indices){const r=ch.chunkY*32+Math.floor(i/32),c=ch.chunkX*32+i%32;layer.surfaces.push({mask:Number(mask),x:(2*c+(r&1)+1)*128,y:(r+1)*64,a:1,d:1});}
Wall.live.add(layer);
assert(Wall.canSeeGround(parent,125,448,131,769),'same-room corner visible from centre');
assert(!Wall.canSeeGround(parent,125,448,131,900),'outside target stays hidden behind front wall');
const actor={parent,scene,activeInHierarchy:true,visible:true};Wall.viewers.set(actor,{x:125,foot:448});
assert.equal(Wall.targetVisible({parent,scene,x:131},769),true);
assert.equal(Wall.targetVisible({parent,scene,x:131},900),false);
assert.equal(Wall.targetVisible(actor,448),true,'observer always visible');
Wall.viewers.clear();assert.equal(Wall.targetVisible({parent,scene,x:131},900),null,'no observer does not hide a scene');
layer.owner={alpha:1,visible:true};
Wall.viewers.set(actor,{x:702.5,foot:833.1});layer.onLateUpdate();
const houseFront=layer.surfaces.filter(s=>(s.mask===10&&s.x===256)||(s.mask===5&&s.x===0)||(s.mask===12&&s.x===128));
assert(houseFront.length===3);
assert(houseFront.every(s=>!layer.revealed.has(s)),'outside observer must not dissolve house front through a doorway glimpse');
Wall.viewers.set(actor,{x:125,foot:448});layer.onLateUpdate();
assert(houseFront.every(s=>layer.revealed.has(s)),'same front walls still reveal distant visible room from inside');
const houseOwner={};layer.owner.parent=houseOwner;interior.setHouseInterior(houseOwner,false);
layer.onLateUpdate();assert.equal(layer.revealed.size,0,'roof outside state overrides all room-wall reveal rays');
interior.setHouseInterior(houseOwner,true);layer.onLateUpdate();
assert(houseFront.every(s=>layer.revealed.has(s)),'entering house enables existing ground visibility rule');
Wall.viewers.set(actor,{x:129,foot:768.2});layer.onLateUpdate();
const missedSides=layer.surfaces.filter(s=>(s.mask===5&&(s.x===-512&&s.y===512||s.x===-128&&s.y===704))||(s.mask===10&&s.x===640&&s.y===576));
assert.equal(missedSides.length,3);
assert(missedSides.every(s=>layer.revealed.has(s)),'three visible side segments stay translucent from the indoor front corner');
interior.setHouseInterior(houseOwner,false);layer.onLateUpdate();assert.equal(layer.revealed.size,0,'outside room still restores every wall');
Wall.viewers.clear();layer.onLateUpdate();assert.equal(layer.revealed.size,0,'no viewer restores walls');
console.log('PASS: same-room targets, opaque walls, openings, both axes/scales, self and absent observer.');
