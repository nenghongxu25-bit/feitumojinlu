# 建筑瓦片制作标准

2026-09-21 用户确认：当前瓦片、碰撞、显隐关系即制作标准。今后的墙壁、室内地板和屋顶只换纹理，其他完全沿用。

## 验收基准

- 唯一试样：`assets/tileset/brick-wall-v1/brick-wall-sample.ls`。
- 墙体：`assets/tileset/brick-wall-v1/brick-wall.tres`、`brick-wall-atlas.png`。
- 地板：试样的 `House_01 / IndoorFloorLayer`，使用 `assets/tileset/forest-style-v2-hd/forest-diamond.tres`。
- 屋顶：`assets/tileset/slate-roof-v1/slate-roof.tres`、两张 `slate-roof-*.png`。
- 独立山墙：`assets/tileset/brick-wall-v1/brick-gable.tres`。屋顶不能重新绑定砖材质。
- 验收备份：`archives/building-standard-20260921.zip`；包内清单记录路径、大小和 SHA-256。
- 旧 README 记录了多轮修改历史。规则冲突时以本标准及最后验收版本为准。

## 固定规格

| 项目 | 标准 |
| --- | --- |
| 投影与墙格 | 2:1 等距，256×128 |
| 墙瓦片 | 256×384，锚点 (128,336)，墙高256，纹理偏移 (0,-144) |
| 墙体厚度 | 沿用现有轮廓；墙脚几何半厚为等距 u/v 坐标的 3/16 |
| 墙图集 | 1044×1556，4×4 共16种连接块，2px留边、4px间隔 |
| 墙块连接 | 沿用 +u/+v/-u/-v 四位连接编号、长墙尺寸、转角及交叉接口 |
| 入口 | 留空墙格；已删除的窄门洞瓦片不再生成 |
| 室内地板 | 沿用原生等距 TileMapLayer；试样地板层缩放0.25，墙格的四分之一尺寸 |
| 屋顶 | 固定7格跨度的双坡屋顶，沿屋脊接长，两个方向共42块；中段/起端/末端编号不变 |
| 屋顶单片 | 320×640，锚点 (160,560)，纹理偏移 (0,-240) |
| 屋顶图集 | 每方向2272×1936，7列×3行，2px留边、4px间隔 |

纹理变体必须保留原有透明轮廓、接缝位置、顶面/侧面分区和受光方向。不得通过缩放图片、重生成不同形状或移动锚点来凑拼接。

## 层级与摆放

房屋放在 ActorLayer 下：House 包含 IndoorFloorLayer、BrickWallLayer、RoofLayer；可选 GableLayer 放在 RoofLayer 下跟随其显隐。墙、地板、屋顶独立选择材质。

沿用 HouseRoofVisibility、IndoorFloorLayer、BrickWallTileLayer、RoofTileLayer。保持墙层无旋转、正缩放，使用现有方向瓦片。地板范围要实际覆盖墙围内部，不能拿包围矩形替代已绘制地板。

当前试样地板位置 (-32,112) 是针对当前墙围的对齐值，不是所有房屋都要硬编码的偏移。新房屋应在相同父坐标下对齐实际格心，保持墙格与地板格的比例。换纹理不得改变已绘制地图。

## 碰撞和显示行为

1. 继续使用墙脚 DepthObstacle 和 TileBlockMovement；等距地面显式坐标换算，不能重新换成有分解误差的 Sprite 斜切矩阵。
2. 当前玩家占地椭圆半宽48、前后半径28；正式玩家脚底偏移80，试样脚底偏移0。换材质不调整接触距离。
3. 屋顶和房屋墙体共用 HouseInteriorState。玩家在室外时屋顶显示、房屋墙保持实心；室内屋顶隐藏。
4. 室内墙体根据墙背缘与玩家之间的地面视线判定半透明，不能因为玩家走到更靠前的位置，就把侧面的前墙恢复实心。墙段不透明度0.28，过渡0.18秒。
5. 实墙一直阻挡移动，也阻挡玩家到目标的视线；入口空格可通行、可看穿。墙透明不等于允许看到另一侧目标。
6. 玩家是 DepthSortable 视野来源；其他带该组件的对象按墙体视线显隐。角色自身豁免；墙前人物与枪作为整体显示，墙后不提前提升到前景。
7. 独立墙（没有房屋祖先）仍使用自身视线和前后判断。普通地板未添加战争迷雾，普通装饰碰撞不自动视为遮光墙。
8. 屋顶淡入淡出0.2秒，出地板范围的200ms缓冲保留。每栋房屋分别控制，不能相互串用状态。

## 新材质流程

- 木墙、水泥墙、白粉墙、石墙、砖墙等只替换材质母图/纹理，使用同一几何和切片流程。
- 原有资产替换纹理时保持 UUID；新增独立材质套装使用新资产 UUID，但瓦片编号、规格、脚本及参数与基准一致。
- 沿用 `tools/bake-brick-wall-tiles.ps1`、`build-brick-wall-kit.cjs`、`bake-slate-roof.ps1`、`build-slate-roof.cjs`、`build-brick-gables.cjs` 的几何约定。必要时仅参数化材质输入与输出，不重写几何规则。
- 提示词参考 `docs/brick-wall-tiles-prompt.txt`、`docs/slate-roof-prompt.txt`；AI只提供材质，最终拼接轮廓由既有规则保证。
- 不重建或覆盖用户地图，不增加重复测试场景；沿用唯一试样检查。

## 验收

运行相关检查：`test-brick-wall-kit.cjs`、`test-brick-wall-save.cjs`、`test-wall-collision.cjs`、`test-wall-foreground.cjs`、`test-wall-vision.cjs`、`test-house-roof.cjs`、`test-slate-roof.cjs`。

在 Laya 运行时复查双方向拼接、贴墙阻挡、入口通行、室内屋顶隐藏、屋外墙实心、室内三段侧墙透明、同侧目标可见与隔墙目标隐藏。按项目要求检查编辑后保存和编译后的表现。
