/** Wall masks use +u,+v,-u,-v bits on a 256x128 diamond grid. */
export function wallFootprints(mask: number): number[][] {
    const t = 3 / 16;
    // Doorway jambs: full-length interfaces, an open middle half, no threshold.
    if (mask === 16) return [[-.5,-t,.25,2*t],[.25,-t,.25,2*t]];
    if (mask === 17) return [[-t,-.5,2*t,.25],[-t,.25,2*t,.25]];
    const boxes = [[-t, -t, 2 * t, 2 * t]];
    if (mask & 1) boxes.push([0, -t, .5, 2 * t]);
    if (mask & 2) boxes.push([-t, 0, 2 * t, .5]);
    if (mask & 4) boxes.push([-.5, -t, .5, 2 * t]);
    if (mask & 8) boxes.push([-t, -.5, 2 * t, .5]);
    return boxes;
}

/** Frontmost ground intersection of a vertical image strip. */
export function wallGroundAtX(mask: number, x: number): number | null {
    let front = -Infinity;
    // The lintel still spans the opening and must render even without floor collision.
    for (const [u, v, w, h] of wallFootprints(mask === 16 ? 5 : mask === 17 ? 10 : mask)) {
        // x=128(u-v), groundY=64(u+v).
        const low = Math.max(u, v + x / 128);
        const high = Math.min(u + w, v + h + x / 128);
        if (low <= high) front = Math.max(front, 128 * high - x / 2);
    }
    return Number.isFinite(front) ? front : null;
}
