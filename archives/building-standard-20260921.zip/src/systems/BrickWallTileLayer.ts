import { DepthObstacle } from './DepthObstacle';
import { wallFootprints, wallGroundAtX } from './BrickWallGeometry';
import {wallBackAtX,wallBlocksSight} from './WallVisionGeometry';
import {houseInteriorState} from './HouseInteriorState';
const { regClass, property } = Laya;

/** Paint real tiles in the editor; expand them for actor interleaving at runtime. */
@regClass('818f8acf-a35f-42d4-b285-b2d8b67d5af8')
@Laya.runInEditor
export class BrickWallTileLayer extends Laya.Script {
    private static readonly live = new Set<BrickWallTileLayer>();
    public static readonly viewers = new Map<Laya.Sprite,{x:number;foot:number;halfWidth:number}>();
    private target: Laya.Sprite | null = null;
    private surfaces: {mask:number;x:number;y:number;a:number;d:number;nodes?:Laya.Sprite[];opacity?:number}[] = [];
    private visionElapsed=100;
    private revealed=new Set<object>();

    public static canSeeGround(parent:Laya.Sprite,ax:number,ay:number,bx:number,by:number):boolean {
        for(const layer of this.live){
            if(layer.target!==parent)continue;
            for(const surface of layer.surfaces)if(wallBlocksSight(surface,ax,ay,bx,by))return false;
        }
        return true;
    }

    /** null means this scene has no active observer; preserve normal rendering. */
    public static targetVisible(node:Laya.Sprite,foot:number):boolean|null {
        let hasViewer=false;
        const parent=node.parent as Laya.Sprite;
        if(!parent)return null;
        for(const [actor,view] of this.viewers){
            if(actor.destroyed||!actor.activeInHierarchy||!actor.visible||actor.scene!==node.scene||!actor.parent)continue;
            if(actor===node)return true;
            hasViewer=true;
            const world=actor.parent as Laya.Sprite;
            const p=world.globalToLocal(parent.localToGlobal(new Laya.Point(node.x,foot),false),false);
            if(this.canSeeGround(world,view.x,view.foot,p.x,p.y))return true;
        }
        return hasViewer?false:null;
    }

    /** A foreground actor is one draw unit, including its held weapon. */
    public static foregroundDepth(parent:Laya.Sprite,x:number,foot:number,reach:number):number {
        if(!parent||reach<=0)return foot;
        // A neighbouring face must never promote an actor through the wall
        // directly in front of their feet (notably on the inside of corners).
        for(const layer of this.live){
            if(layer.target!==parent)continue;
            for(const s of layer.surfaces){
                const ground=wallGroundAtX(s.mask,(x-s.x)/s.a);
                if(ground===null)continue;
                const gap=s.y+ground*s.d-foot;
                if(gap>0&&gap<=256*s.d)return foot;
            }
        }
        let depth=foot;
        for(const layer of this.live){
            if(layer.target!==parent)continue;
            for(const s of layer.surfaces){
                const localX=(x-s.x)/s.a;
                // Follow the face across tile seams within the weapon's span.
                if(Math.abs(localX)>128+reach/s.a)continue;
                let ground=wallGroundAtX(s.mask,localX);
                if(ground===null){
                    // The muzzle can overlap an adjacent corner tile even when
                    // the feet are outside that tile's horizontal image span.
                    const sign=localX<0?-1:1;
                    for(let edge=126;edge>=0;edge-=2){
                        const px=edge*sign,g=wallGroundAtX(s.mask,px);
                        const inner=wallGroundAtX(s.mask,px-sign*2);
                        if(g===null||inner===null)continue;
                        ground=g+(g-inner)/(sign*2)*(localX-px);break;
                    }
                }
                if(ground===null)continue;
                const face=s.y+ground*s.d;
                if(foot<face||foot-face>reach)continue;
                for(let sx=0;sx<256;sx+=4){
                    const px=s.x+(sx+2-128)*s.a;
                    if(Math.abs(px-x)>reach)continue;
                    const g=wallGroundAtX(s.mask,sx+2-128);
                    if(g!==null)depth=Math.max(depth,s.y+g*s.d+.01);
                }
            }
        }
        return depth;
    }
    @property({ type: Laya.Sprite, caption: '人物所在层（空则自动查找ActorLayer）' })
    public actorLayer: Laya.Sprite | null = null;
    @property({type:Number,caption:'遮挡玩家时墙体不透明度'})
    public occludedAlpha=.28;
    @property({type:Number,caption:'墙体透明过渡秒数'})
    public occlusionFadeSeconds=.18;
    private pieces: Laya.Sprite[] = [];
    private textures: Laya.Texture[] = [];
    private renderer: Laya.TileMapLayer | null = null;
    private started = false;
    private originalEnabled = true;

    onStart(): void { if (!Laya.LayaEnv.isPlaying) return; this.started = true; this.rebuild(); }
    onEnable(): void { this.protectPaintedCells(); if (Laya.LayaEnv.isPlaying && this.started) this.rebuild(); }
    onUpdate(): void { if (!Laya.LayaEnv.isPlaying) this.protectPaintedCells(); }
    onLateUpdate():void {
        if(!Laya.LayaEnv.isPlaying)return;
        const owner=this.owner as Laya.Sprite;
        const step=this.occlusionFadeSeconds<=0?1:Math.min(1,Laya.timer.delta/(1000*this.occlusionFadeSeconds));
        const interior=houseInteriorState(owner);
        const roomAllowsReveal=interior!==false;
        if(!roomAllowsReveal)this.revealed.clear();
        this.visionElapsed+=Laya.timer.delta;
        if(roomAllowsReveal&&this.visionElapsed>=100){
            this.visionElapsed=0;this.revealed.clear();
            for(const s of this.surfaces){
                for(const [actor,view] of BrickWallTileLayer.viewers){
                    if(actor.destroyed||!actor.activeInHierarchy||!actor.visible||actor.parent!==this.target)continue;
                    let visible=false;
                    // Sample the ground hidden by the projected wall, not the
                    // observer's distance to it. Rays still hit opaque footprints.
                    for(let localX=-112;localX<=112&&!visible;localX+=32){
                        const back=wallBackAtX(s.mask,localX),front=wallGroundAtX(s.mask,localX);
                        if(back===null||front===null)continue;
                        // A visible patch seen around an end or through a door
                        // must not dissolve a wall that is behind the observer.
                        // Within a room, visible side-wall backs must also yield
                        // when the player walks ahead of their screen-space Y.
                        if(interior!==true&&s.y+front*s.d<=view.foot)continue;
                        const x=s.x+localX*s.a;
                        // Require visibility immediately behind this wall face.
                        // A distant patch reached through a different doorway
                        // is not evidence that this face should disappear.
                        const y=s.y+(back-2)*s.d;
                        if(BrickWallTileLayer.canSeeGround(this.target,view.x,view.foot,x,y))visible=true;
                    }
                    if(visible){this.revealed.add(s);break;}
                }
            }
        }
        for(const s of this.surfaces){
            const blocked=this.revealed.has(s);
            const goal=blocked?Math.max(0,Math.min(1,this.occludedAlpha)):1;
            const current=s.opacity??1;
            s.opacity=current+Math.sign(goal-current)*Math.min(Math.abs(goal-current),step);
            for(const node of s.nodes||[]){node.alpha=owner.alpha*s.opacity;node.visible=owner.visible;}
        }
    }
    onDisable(): void { this.clear(); }
    onDestroy(): void { this.clear(); }

    /** Engine _setCell removes the new gid from _refGids when replacing the
     * last cell of the old gid. Keep serialization based on the actual cells.
     * Scoped to this wall layer; never changes the editor's global prototypes. */
    private protectPaintedCells(): void {
        const layer = this.owner.getComponent(Laya.TileMapLayer);
        const chunks = layer && (layer as any)._chunkDatas;
        if (!chunks) return;
        for (const row of Object.values(chunks)) for (const chunk of Object.values(row)) {
            const data = chunk as any;
            if (!data._cellDataRefMap || !data._refGids) continue;
            const repair = () => {
                const gids = Object.keys(data._cellDataRefMap)
                    .filter(key => data._cellDataRefMap[key]?.length > 0).map(Number);
                data._refGids.splice(0, data._refGids.length, ...gids);
            };
            repair();
            if (Object.prototype.hasOwnProperty.call(data, 'compressData')) continue;
            const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(data), 'compressData');
            if (!descriptor?.get || !descriptor.set) continue;
            Object.defineProperty(data, 'compressData', {
                configurable: true,
                get: () => { repair(); return descriptor.get.call(data); },
                set: value => descriptor.set.call(data, value)
            });
        }
    }

    private find(root: Laya.Node): Laya.Sprite | null {
        if (root.name === 'ActorLayer') return root as Laya.Sprite;
        for (const child of root.children) { const found = this.find(child); if (found) return found; }
        return null;
    }

    /** Call after runtime tile edits; normal editor painting rebuilds on Play. */
    public rebuild(): void {
        if (!Laya.LayaEnv.isPlaying) return;
        this.protectPaintedCells();
        this.clear();
        const owner = this.owner as Laya.Sprite;
        const target = this.actorLayer || (owner.scene && this.find(owner.scene));
        const layer = owner.getComponent(Laya.TileMapLayer);
        if (!target || !layer?.tileSet) { console.error('[BrickWallTileLayer] Missing ActorLayer or TileSet.'); return; }
        this.target=target;BrickWallTileLayer.live.add(this);
        // This engine has no public cell iterator. Read its chunk table, then use public
        // chunk accessors; screen bounds are unreliable for overhanging tall tiles.
        const chunks = (layer as any)._chunkDatas as Record<string, Record<string, Laya.TileMapChunkData>>;
        if (!chunks) { console.error('[BrickWallTileLayer] Unsupported engine chunk layout.'); return; }
        const map = (x: number, y: number): Laya.Point => target.globalToLocal(owner.localToGlobal(new Laya.Point(x,y), false), false);
        const origin = map(0,0), ax = map(1,0), ay = map(0,1);
        const a=ax.x-origin.x,b=ax.y-origin.y,c=ay.x-origin.x,d=ay.y-origin.y;
        // Rotating the whole wall layer would invalidate screen-space vertical sorting.
        if (Math.abs(b)>1e-5 || Math.abs(c)>1e-5 || a<=0 || d<=0) { console.error('[BrickWallTileLayer] Keep wall layer axes unrotated and scales positive.'); return; }
        let count = 0;
        const center = new Laya.Vector2();
        const cells: {x:number;y:number;info:Laya.ChunkCellInfo}[]=[];
        for(const row of Object.values(chunks))for(const chunk of Object.values(row)){
            for(const indices of Object.values(chunk.compressData))for(const index of indices){
                const size=layer.renderTileSize;
                cells.push({x:chunk.chunkX*size+index%size,y:chunk.chunkY*size+Math.floor(index/size),info:chunk.getCell(index)});
            }
        }
        for (const {x,y,info} of cells) {
            if (!info?.cell) continue;
            const cell=info.cell, alt=cell.cellowner, group=alt.owner;
            const mask=group.id===1 ? 16+alt.localPos.x : alt.localPos.y*4+alt.localPos.x;
            if (mask<0 || mask>17 || info._transFlag || cell.transFlag) {
                console.error('[BrickWallTileLayer] Use the supplied direction tiles without rotate/flip.'); continue;
            }
            layer.gridToPixel(x,y,center);
            const surface=map(center.x,center.y);
            const nodes:Laya.Sprite[]=[];
            this.surfaces.push({mask,x:surface.x,y:surface.y,a,d,nodes,opacity:1});
            const texture=new Laya.Texture(group.atlas); this.textures.push(texture);
            const atlasX=2+alt.localPos.x*260,atlasY=2+alt.localPos.y*388;
            // Thin strips sort by their own ground intersection, not the whole wall's midpoint.
            for(let sx=0;sx<256;sx+=4){
                const ground=wallGroundAtX(mask,sx+2-128);
                if(ground===null)continue;
                const cut=Laya.Texture.createFromTexture(texture,atlasX+sx,atlasY,4,384); this.textures.push(cut);
                const node=new Laya.Sprite(); node.name='BrickWallVisual'; node.texture=cut; node.size(4,384);
                const pos=map(center.x+sx-128,center.y-336);
                target.addChild(node);node.pos(pos.x,pos.y);node.scale(a,d);
                node.zOrder=map(center.x+sx-126,center.y+ground).y;
                node.visible=owner.visible;node.alpha=owner.alpha; this.pieces.push(node);
                nodes.push(node);
            }
            for(const [u,v,w,h] of wallFootprints(mask)){
                const node=new Laya.Sprite();node.name='BrickWallFootprint';target.addChild(node);
                const p=map(center.x,center.y);
                node.pos(p.x,p.y);node.scale(a,d);
                const obstacle=node.addComponent(DepthObstacle);
                obstacle.isometricGround=true;
                obstacle.blockX=u;obstacle.blockY=v;obstacle.blockWidth=w;obstacle.blockHeight=h;
                this.pieces.push(node);
            }
            count++;
        }
        this.renderer=layer;this.originalEnabled=layer.enabled;layer.enabled=false;
        console.info(`[BrickWallTileLayer] ${count} painted cells, ${this.pieces.length} render/collision pieces, height=256.`);
    }

    private clear(): void {
        BrickWallTileLayer.live.delete(this);this.surfaces.length=0;this.target=null;
        this.revealed.clear();this.visionElapsed=100;
        for (const node of this.pieces) if(!node.destroyed) node.destroy(true);
        this.pieces.length=0;
        for (let i=this.textures.length-1;i>=0;i--) this.textures[i].destroy();
        this.textures.length=0;
        if(this.renderer && !this.renderer.destroyed) this.renderer.enabled=this.originalEnabled;
        this.renderer=null;
    }
}
