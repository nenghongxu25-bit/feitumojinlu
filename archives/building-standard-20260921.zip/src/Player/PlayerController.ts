const { regClass, property } = Laya;

import { PlayerMovementController } from "./PlayerMovementController";
import { PlayerUIHints } from "./PlayerUIHints";
import { PlayerCombatController } from "./PlayerCombatController";
import type { PlayerAttackOptions } from "./PlayerCombatController";
import { PlayerAnimationController } from "./PlayerAnimationController";
import { PlayerEquipmentVisualController } from "./PlayerEquipmentVisualController";
import { PlayerRangedController } from "./PlayerRangedController";
import { DataManager } from "../systems/datamanager";
import { installSpineRuntimeGuard } from "../runtime/SpineRuntimeGuard";
import { RunResultPanel } from "../PlayUI/RunResult/RunResultPanel";

installSpineRuntimeGuard();

@regClass()
export class PlayerController extends Laya.Script {
    public static activeInstance: PlayerController | null = null;

    @property(Number)
    public walkSpeed: number = 200;

    @property(Number)
    public runSpeed: number = 320;

    @property(Number)
    public moveSpeed: number = 0;

    @property(Number)
    public tileBlockHalfWidth: number = 48;
    @property({type:Number,caption:'脚底碰撞前后半径'})
    public tileBlockHalfDepth: number = 28;

    @property(Number)
    public tileBlockFootOffsetY: number = 80;


    @property(Boolean)
    public footstepSoundEnabled: boolean = true;

    @property(String)
    public cunzhuangWalkSoundUrl: string = "sound/sfx/walk/walk_wood.mp3";

    @property(String)
    public cunzhuangRunSoundUrl: string = "sound/sfx/run/run_wood.mp3";

    @property(String)
    public forestWalkSoundUrl: string = "sound/sfx/walk/walk_grass.mp3";

    @property(String)
    public forestRunSoundUrl: string = "sound/sfx/run/run_grass.mp3";

    @property(String)
    public mineWalkSoundUrl: string = "sound/sfx/walk/walk_floor.wav";

    @property(String)
    public mineRunSoundUrl: string = "sound/sfx/run/run_inside_floor.mp3";

    @property(Number)
    public walkFootstepInterval: number = 420;

    @property(Number)
    public runFootstepInterval: number = 300;

    @property(Number)
    public walkFootstepPlaybackRate: number = 1;

    @property(Number)
    public runFootstepPlaybackRate: number = 1;

    @property(Number)
    public footstepPlaybackRateVariance: number = 0;

    @property(Boolean)
    public isRunning: boolean = false;

    @property(Laya.Node)
    public joystickNode: Laya.Node | null = null;

    @property(Laya.Node)
    public spineNode: Laya.Node | null = null;

    @property(Laya.Node)
    public attackNode: Laya.Node | null = null;

    @property(Laya.Node)
    public detectNode: Laya.Node | null = null;

    @property(Laya.Node)
    public stateText: Laya.Node | null = null;

    @property(Laya.Node)
    public itemText: Laya.Node | null = null;

    @property(Laya.Node)
    public hpFillNode: Laya.Node | null = null;

    @property(Laya.Node)
    public hpBarNode: Laya.Node | null = null;

    @property(Laya.Node)
    public staminaFillNode: Laya.Node | null = null;

    @property(Laya.Node)
    public staminaBarNode: Laya.Node | null = null;

    @property(Laya.Node)
    public weaponSlotNode: Laya.Node | null = null;

    @property(Laya.Node)
    public weaponIconNode: Laya.Node | null = null;

    @property(Laya.Node)
    public rangedWeaponRootNode: Laya.Node | null = null;

    @property(Laya.Node)
    public rangedWeaponImageNode: Laya.Node | null = null;

    @property(String)
    public weaponSpineSlotName: string = "";

    @property(String)
    public weaponMeleeSpineSlotName: string = "weapon_melee_slot";

    @property(String)
    public weaponRangedSpineSlotName: string = "weapon_ranged_slot";

    @property(String)
    public insertPlateSpineSlotName: string = "";

    @property(String)
    public helmetSpineSlotName: string = "";

    @property(String)
    public armorSpineSlotName: string = "";

    @property(Number)
    public currentHp: number = 100;

    @property(Number)
    public maxHp: number = 100;

    @property(Number)
    public hpFillFullWidth: number = 70;

    @property(Number)
    public currentStamina: number = 100;

    @property(Number)
    public maxStamina: number = 100;

    @property(Number)
    public runRecoverStaminaThreshold: number = 30;

    @property(Number)
    public staminaFillFullWidth: number = 70;

    @property(Number)
    public hpBarRightX: number = -35;

    @property(Number)
    public hpBarLeftX: number = 35;

    @property(Number)
    public staminaBarRightX: number = -35;

    @property(Number)
    public staminaBarLeftX: number = 35;

    @property(String)
    public deathReturnSceneUrl: string = "scenes/cunzhuang.ls";

    @property(Number)
    public initialFacingSign: number = 1;

    @property(Number)
    public attackAreaRightX: number = -100;

    @property(Number)
    public attackAreaLeftX: number = 0;

    @property(Number)
    public attackCooldown: number = 300;

    @property(Number)
    public attackPower: number = 10;

    @property(Number)
    public baseAttackPower: number = 10;

    @property(Number)
    public attackSpeed: number = 1;

    @property(Number)
    public attackDamageRange: number = 120;

    @property(Number)
    public attackHitboxShowDelay: number = 0;

    @property(Number)
    public attackHitboxVisibleDuration: number = 200;

    @property(Number)
    public rangedAttackRange: number = 520;

    @property(Number)
    public rangedAttackWidth: number = 90;

    @property(Number)
    public rangedAttackHitDelay: number = 220;

    @property(String)
    public rangedAttackSoundUrl: string = "sound/sfx/weapon/ranged/akm/akm_singleshot.mp3";

    @property(Number)
    public rangedWeaponAimRotationOffset: number = 0;

    @property(Number)
    public rangedChargeDuration: number = 900;

    @property(Number)
    public rangedMinDamageMultiplier: number = 0.75;

    @property(Number)
    public rangedMaxDamageMultiplier: number = 2;

    @property(String)
    public rangedBulletTextureUrl: string = "res://atlas/picture/ui/zidan.png";

    @property(Number)
    public rangedBulletSpeed: number = 900;

    @property(Number)
    public rangedBulletScale: number = 1;

    @property(Number)
    public rangedBulletRotationOffset: number = 0;

    @property(Number)
    public rangedBulletSpawnOffsetX: number = 0;

    @property(Number)
    public rangedBulletSpawnOffsetY: number = 0;

    @property(String)
    public idleAnimation: string = "idle/idle_melee_swing";

    @property(String)
    public walkAnimation: string = "walk/walk_body_lower";

    @property(String)
    public runAnimation: string = "run/run_body_lower";

    @property({ type: Number, caption: "Run Animation Rate", tips: "Playback rate used only by the player run Spine locomotion animation." })
    public runAnimationPlaybackRate: number = 1.3;

    @property(String)
    public attackAnimation: string = "attack/attack_melee_swing";

    @property(String)
    public rangedAttackAnimation: string = "attack/attack_ranged_firearm";

    @property(Boolean)
    public layeredSpineAnimationEnabled: boolean = true;

    @property(String)
    public upperIdleAnimation: string = "idle/idle_melee_swing";

    @property(String)
    public upperWalkAnimation: string = "walk/walk_body_upper_melee_swing";

    @property(String)
    public upperRunAnimation: string = "run/run_body_upper_melee_swing";

    @property(String)
    public rangedUpperIdleAnimation: string = "idle/idle_ranged_firearm";

    @property(String)
    public rangedUpperWalkAnimation: string = "walk/walk_body_upper_ranged_firearm";

    @property(String)
    public rangedUpperRunAnimation: string = "run/run_body_upper_ranged_firearm";

    @property(Number)
    public attackAnimationDuration: number = 1067;

    public movement!: PlayerMovementController;
    public ui!: PlayerUIHints;
    public combat!: PlayerCombatController;
    public animation!: PlayerAnimationController;
    public equipment!: PlayerEquipmentVisualController;
    public ranged!: PlayerRangedController;
    private attackToken: number = 0;
    private staminaTickElapsed: number = 0;
    private readonly fillBaseTransforms = new WeakMap<object, { width: number; scaleX: number }>();
    private runStaminaLocked: boolean = false;
    private deathReturnTriggered: boolean = false;
    private lastEquipmentSignature: string = "__init";
    private defaultRangedBulletSpeed: number = 0;

    onAwake(): void {
        PlayerController.activeInstance = this;
        this.movement = new PlayerMovementController(this);
        this.ui = new PlayerUIHints(this);
        this.combat = new PlayerCombatController(this);
        this.animation = new PlayerAnimationController(this);
        this.equipment = new PlayerEquipmentVisualController(this);
        this.ranged = new PlayerRangedController(this);
        this.defaultRangedBulletSpeed = Math.max(1, Number(this.rangedBulletSpeed) || 1);
        this.movement.onAwake();
        this.ui.onAwake();
        this.setRunningState(this.isRunning);
        this.combat.setAttackNodeVisible(false);
        this.syncHpFromData();
        this.syncStaminaFromData();
        this.refreshHpBar();
        this.refreshStaminaBar();
        this.syncEquipmentStats();
        this.animation.onAwake();
        this.equipment.scheduleInitialization();
    }

    onStart(): void {
        PlayerController.activeInstance = this;
        this.movement.onStart();
        this.ui.onStart();
        this.setRunningState(this.isRunning);
        this.combat.setAttackNodeVisible(false);
        this.syncHpFromData();
        this.syncStaminaFromData();
        this.refreshHpBar();
        this.refreshStaminaBar();
        this.syncEquipmentStats();
        this.animation.onStart();
        this.equipment.scheduleInitialization();
    }

    onUpdate(): void {
        this.movement.onUpdate();
        this.updateStamina();
        this.syncEquipmentStats();
        this.animation.onUpdate();
        this.syncRangedWeaponSpineSlotHidden();
        this.ranged.syncAimRotation("update");
    }

    onLateUpdate(): void {
        this.ranged.syncAimRotation("late");
    }

    onDestroy(): void {
        if (PlayerController.activeInstance === this) {
            PlayerController.activeInstance = null;
        }

        this.ranged?.onDestroy();
        this.equipment?.onDestroy();
        this.animation?.onDestroy();
        this.combat?.onDestroy();
        this.ui?.onDestroy();
    }

    public playAttack(queueIfBusy: boolean = false, options: PlayerAttackOptions = {}): boolean {
        return this.combat.playAttack(queueIfBusy, options);
    }

    public clearQueuedAttack(): void {
        this.combat.clearQueuedAttack();
    }

    public setAttackFacingByDirection(x: number, y: number = 0): boolean {
        return this.movement.setAttackFacingByDirection(x, y);
    }

    public clearAttackFacingOverride(): void {
        this.movement.clearAttackFacingOverride();
    }

    public setRangedWeaponAimByDirection(x: number, y: number = 0): void {
        this.ranged.setAimByDirection(x, y);
    }

    public clearRangedWeaponAim(): void {
        this.ranged.clearAim();
    }

    public beginAttackHit(): number {
        this.attackToken += 1;
        return this.attackToken;
    }

    public endAttackHit(): void {
        this.attackToken = 0;
    }

    public getAttackToken(): number {
        return this.attackToken;
    }

    public syncEquipmentStats(): void {
        const dataManager = DataManager.getInstance();
        const weapon = dataManager.getEquippedItem("weapon");
        const nextBulletSpeed = dataManager.getEquipmentBulletSpeed(this.defaultRangedBulletSpeed || this.rangedBulletSpeed);
        const signature = `${this.baseAttackPower}:${nextBulletSpeed}:${weapon ? `${weapon.itemId}:${weapon.count}` : ""}`;
        if (this.lastEquipmentSignature === signature) {
            return;
        }

        this.lastEquipmentSignature = signature;
        this.attackPower = Math.max(0, Math.floor((this.baseAttackPower || 0) + dataManager.getEquipmentAttackBonus()));
        this.attackSpeed = Math.max(0.1, dataManager.getEquipmentAttackSpeed());
        this.rangedBulletSpeed = nextBulletSpeed;
        this.animation?.invalidateLocomotion();
        this.equipment.scheduleInitialization();
    }

    public setRunningState(value: boolean): void {
        this.updateRunStaminaLock();
        this.isRunning = value && this.canStartRunning();
        this.moveSpeed = this.isRunning ? this.runSpeed : 0;
    }

    public setRunning(value: boolean): void {
        this.setRunningState(value);
    }

    public toggleRunning(): void {
        this.setRunningState(!this.isRunning);
    }

    public canStartRunning(): boolean {
        return this.currentStamina > 0 && !this.runStaminaLocked;
    }

    public isRunStaminaLocked(): boolean {
        return this.runStaminaLocked;
    }

    public showState(text: string, duration: number = 1200): void {
        this.ui.showState(text, duration);
    }

    public showItem(text: string, duration: number = 1500): void {
        this.ui.showItem(text, duration);
    }

    public hideStateText(): void {
        this.ui.hideStateText();
    }

    public hideItemText(): void {
        this.ui.hideItemText();
    }

    public setHp(currentHp: number, maxHp: number = this.maxHp): void {
        this.maxHp = Math.max(1, Math.floor(maxHp));
        this.currentHp = Math.max(0, Math.min(Math.floor(currentHp), this.maxHp));
        DataManager.getInstance().setPlayerHp(this.currentHp, this.maxHp);
        this.refreshHpBar();

        if (this.currentHp <= 0) {
            this.returnToDeathScene();
        }
    }

    public takeDamage(amount: number): void {
        const damage = Math.max(0, Math.floor(amount));
        if (damage <= 0 || this.currentHp <= 0) {
            return;
        }

        this.setHp(this.currentHp - damage, this.maxHp);
    }

    public refreshHpBar(): void {
        const fill = this.hpFillNode as any;
        if (!fill) {
            return;
        }

        const ratio = this.currentHp / Math.max(1, this.maxHp);
        this.applyHpFillWidth(fill, Math.max(0, this.hpFillFullWidth * ratio));
        this.syncStatusBarTransform();
    }

    public syncHpFromData(): void {
        const stats = DataManager.getInstance().getPlayerStats();
        this.maxHp = Math.max(1, Math.floor(stats.maxHp || 100));
        const currentHp = Number.isFinite(stats.currentHp) ? stats.currentHp : this.maxHp;
        this.currentHp = Math.max(0, Math.min(Math.floor(currentHp), this.maxHp));
        this.refreshHpBar();
    }

    public setStamina(currentStamina: number, maxStamina: number = this.maxStamina): void {
        this.maxStamina = Math.max(1, Math.floor(maxStamina));
        this.currentStamina = Math.max(0, Math.min(Math.floor(currentStamina), this.maxStamina));
        this.updateRunStaminaLock();
        DataManager.getInstance().setPlayerStamina(this.currentStamina, this.maxStamina);
        if (!this.canStartRunning() && this.isRunning) {
            this.setRunningState(false);
        }
        this.refreshStaminaBar();
    }

    public consumeStaminaForCompletedAttack(): void {
        this.setStamina(this.currentStamina - 10, this.maxStamina);
    }

    public syncStaminaFromData(): void {
        const stats = DataManager.getInstance().getPlayerStats();
        this.maxStamina = Math.max(1, Math.floor(stats.maxStamina || 100));
        const currentStamina = Number.isFinite(stats.currentStamina) ? stats.currentStamina : this.maxStamina;
        this.currentStamina = Math.max(0, Math.min(Math.floor(currentStamina), this.maxStamina));
        this.updateRunStaminaLock();
        if (!this.canStartRunning() && this.isRunning) {
            this.setRunningState(false);
        }
        this.refreshStaminaBar();
    }

    public refreshStaminaBar(): void {
        const fill = this.staminaFillNode as any;
        if (!fill) {
            return;
        }

        const ratio = this.currentStamina / Math.max(1, this.maxStamina);
        const width = Math.max(0, this.staminaFillFullWidth * ratio);
        this.applyHpFillWidth(fill, width);
        this.syncStatusBarTransform();
    }

    public syncStatusBarTransform(): void {
        const facingSign = this.movement ? this.movement.getFacingSign() : this.initialFacingSign >= 0 ? 1 : -1;
        this.applyCounterTransform(this.hpBarNode || this.hpFillNode?.parent || null, facingSign, this.hpBarRightX, this.hpBarLeftX);
        this.applyCounterTransform(this.staminaBarNode || this.staminaFillNode?.parent || null, facingSign, this.staminaBarRightX, this.staminaBarLeftX);
    }

    private updateStamina(): void {
        this.staminaTickElapsed += Math.max(0, Laya.timer.delta || 0);

        while (this.staminaTickElapsed >= 500) {
            this.staminaTickElapsed -= 500;

            if (this.isRunning && this.movement.getIsMovingNow()) {
                this.setStamina(this.currentStamina - 10, this.maxStamina);
            } else {
                this.setStamina(this.currentStamina + 3, this.maxStamina);
            }
        }
    }

    private updateRunStaminaLock(): void {
        if (this.currentStamina <= 0) {
            this.runStaminaLocked = true;
            return;
        }

        const recoverThreshold = Math.max(1, Math.min(this.maxStamina, Math.floor(this.runRecoverStaminaThreshold || 30)));
        if (this.currentStamina >= recoverThreshold) {
            this.runStaminaLocked = false;
        }
    }

    private returnToDeathScene(): void {
        if (this.deathReturnTriggered) {
            return;
        }

        const url = String(this.deathReturnSceneUrl || "scenes/cunzhuang.ls").trim();
        if (!url) {
            return;
        }

        this.deathReturnTriggered = true;
        Laya.timer.once(0, null, () => {
            const returnToBase = (): void => {
                DataManager.getInstance().returnToBaseAfterDeath(url);
                Laya.Scene.open(url);
            };

            if (RunResultPanel.showFailed(2500, returnToBase)) {
                return;
            }

            returnToBase();
        });
    }

    private applyHpFillWidth(fill: any, width: number): void {
        let base = this.fillBaseTransforms.get(fill as object);
        if (!base) {
            base = {
                width: Math.max(0, Number(fill.width) || width),
                scaleX: Number(fill.scaleX) || 1,
            };
            this.fillBaseTransforms.set(fill as object, base);
        }

        // Keep the DrawRect at its original size and scale the node. This
        // reliably repaints on mobile/mini-game renderers where changing a
        // cached DrawRect width alone can leave the old pixels on screen.
        const ratio = base.width > 0 ? Math.max(0, Math.min(1, width / base.width)) : 0;
        fill.width = base.width;
        fill.scaleX = base.scaleX * ratio;

        const commands = fill._gcmds;
        if (!Array.isArray(commands)) {
            return;
        }

        for (let i = 0; i < commands.length; i++) {
            const command = commands[i];
            if (command && "width" in command) {
                command.width = base.width;
            }
        }
    }

    private applyCounterTransform(node: Laya.Node | null, facingSign: number, rightX: number, leftX: number): void {
        const sprite = node as Laya.Sprite | null;
        if (!sprite) {
            return;
        }

        const facingRight = facingSign === (this.initialFacingSign >= 0 ? 1 : -1);
        sprite.x = facingRight ? leftX : rightX;
        sprite.scaleX = facingRight ? -1 : 1;
    }

    public syncWeaponSpineSlot(force: boolean = false): boolean {
        return this.equipment.syncWeaponSpineSlot(force);
    }

    public resolveUpperLocomotionAnimation(lowerAnimation: string): string {
        const ranged = this.isEquippedRangedWeapon();
        const idle = ranged
            ? this.rangedUpperIdleAnimation || this.upperIdleAnimation
            : this.upperIdleAnimation;

        if (lowerAnimation === this.runAnimation) {
            return ranged
                ? this.rangedUpperRunAnimation || idle || lowerAnimation
                : this.upperRunAnimation || idle || lowerAnimation;
        }

        if (lowerAnimation === this.walkAnimation) {
            return ranged
                ? this.rangedUpperWalkAnimation || idle || lowerAnimation
                : this.upperWalkAnimation || idle || lowerAnimation;
        }

        return idle || lowerAnimation;
    }

    public resolveAttackAnimation(): string {
        if (this.isEquippedRangedWeapon()) {
            return this.rangedAttackAnimation || this.attackAnimation;
        }

        return this.attackAnimation;
    }

    public syncEquipmentSpineSlots(force: boolean = false): boolean {
        return this.equipment.syncEquipmentSpineSlots(force);
    }

    public refreshEquipmentFromData(): void {
        this.equipment.refreshFromData();
    }

    public refreshEquipmentVisualsFromData(): boolean {
        return this.equipment.refreshVisualsFromData();
    }

    public invalidateEquipmentStats(): void {
        this.lastEquipmentSignature = "__force";
    }

    public isEquippedRangedWeapon(): boolean {
        return this.equipment.isEquippedRangedWeapon();
    }

    private syncRangedWeaponSpineSlotHidden(): void {
        if (!this.equipment || !this.isEquippedRangedWeapon()) {
            return;
        }

        this.equipment.syncWeaponSpineSlot(false);
    }

    public applyRangedAttackDamage(options: PlayerAttackOptions = {}): boolean {
        return this.ranged.applyDamage(options);
    }

    public spawnRangedBullet(options: PlayerAttackOptions = {}): void {
        this.ranged.spawnBullet(options);
    }

    public resolveRangedChargeRatio(heldMs: number, dragRatio: number): number {
        return this.ranged.resolveChargeRatio(heldMs, dragRatio);
    }

    public snapshot(): Record<string, any> {
        return {
            walkSpeed: this.walkSpeed,
            runSpeed: this.runSpeed,
            moveSpeed: this.moveSpeed,
            tileBlockHalfWidth: this.tileBlockHalfWidth,
            tileBlockFootOffsetY: this.tileBlockFootOffsetY,
            footstepSoundEnabled: this.footstepSoundEnabled,
            cunzhuangWalkSoundUrl: this.cunzhuangWalkSoundUrl,
            cunzhuangRunSoundUrl: this.cunzhuangRunSoundUrl,
            forestWalkSoundUrl: this.forestWalkSoundUrl,
            forestRunSoundUrl: this.forestRunSoundUrl,
            mineWalkSoundUrl: this.mineWalkSoundUrl,
            mineRunSoundUrl: this.mineRunSoundUrl,
            walkFootstepInterval: this.walkFootstepInterval,
            runFootstepInterval: this.runFootstepInterval,
            walkFootstepPlaybackRate: this.walkFootstepPlaybackRate,
            runFootstepPlaybackRate: this.runFootstepPlaybackRate,
            footstepPlaybackRateVariance: this.footstepPlaybackRateVariance,
            isRunning: this.isRunning,
            idleAnimation: this.idleAnimation,
            walkAnimation: this.walkAnimation,
            runAnimation: this.runAnimation,
            runAnimationPlaybackRate: this.runAnimationPlaybackRate,
            attackAnimation: this.attackAnimation,
            attackAnimationDuration: this.attackAnimationDuration,
            joystickNode: this.joystickNode ? this.joystickNode.name : null,
            spineNode: this.spineNode ? this.spineNode.name : null,
            attackNode: this.attackNode ? this.attackNode.name : null,
            detectNode: this.detectNode ? this.detectNode.name : null,
            stateText: this.stateText ? this.stateText.name : null,
            itemText: this.itemText ? this.itemText.name : null,
            hpFillNode: this.hpFillNode ? this.hpFillNode.name : null,
            hpBarNode: this.hpBarNode ? this.hpBarNode.name : null,
            staminaFillNode: this.staminaFillNode ? this.staminaFillNode.name : null,
            staminaBarNode: this.staminaBarNode ? this.staminaBarNode.name : null,
            weaponSlotNode: this.weaponSlotNode ? this.weaponSlotNode.name : null,
            weaponIconNode: this.weaponIconNode ? this.weaponIconNode.name : null,
            rangedWeaponRootNode: this.rangedWeaponRootNode ? this.rangedWeaponRootNode.name : null,
            rangedWeaponImageNode: this.rangedWeaponImageNode ? this.rangedWeaponImageNode.name : null,
            weaponSpineSlotName: this.weaponSpineSlotName,
            weaponMeleeSpineSlotName: this.weaponMeleeSpineSlotName,
            weaponRangedSpineSlotName: this.weaponRangedSpineSlotName,
            insertPlateSpineSlotName: this.insertPlateSpineSlotName,
            helmetSpineSlotName: this.helmetSpineSlotName,
            armorSpineSlotName: this.armorSpineSlotName,
            equipment: this.equipment ? this.equipment.snapshot() : null,
            currentHp: this.currentHp,
            maxHp: this.maxHp,
            hpFillFullWidth: this.hpFillFullWidth,
            currentStamina: this.currentStamina,
            maxStamina: this.maxStamina,
            staminaFillFullWidth: this.staminaFillFullWidth,
            hpBarRightX: this.hpBarRightX,
            hpBarLeftX: this.hpBarLeftX,
            staminaBarRightX: this.staminaBarRightX,
            staminaBarLeftX: this.staminaBarLeftX,
            deathReturnSceneUrl: this.deathReturnSceneUrl,
            owner: this.owner ? this.owner.name : null,
            scaleX: this.owner ? (this.owner as Laya.Sprite).scaleX : null,
            initialFacingSign: this.initialFacingSign,
            attackAreaRightX: this.attackAreaRightX,
            attackAreaLeftX: this.attackAreaLeftX,
            attackCooldown: this.attackCooldown,
            attackPower: this.attackPower,
            baseAttackPower: this.baseAttackPower,
            attackSpeed: this.attackSpeed,
            attackDamageRange: this.attackDamageRange,
            attackHitboxShowDelay: this.attackHitboxShowDelay,
            attackHitboxVisibleDuration: this.attackHitboxVisibleDuration,
            rangedAttackRange: this.rangedAttackRange,
            rangedAttackWidth: this.rangedAttackWidth,
            rangedAttackHitDelay: this.rangedAttackHitDelay,
            rangedAttackSoundUrl: this.rangedAttackSoundUrl,
            rangedWeaponAimRotationOffset: this.rangedWeaponAimRotationOffset,
            rangedChargeDuration: this.rangedChargeDuration,
            rangedMinDamageMultiplier: this.rangedMinDamageMultiplier,
            rangedMaxDamageMultiplier: this.rangedMaxDamageMultiplier,
            rangedBulletTextureUrl: this.rangedBulletTextureUrl,
            rangedBulletSpeed: this.rangedBulletSpeed,
            rangedBulletScale: this.rangedBulletScale,
            rangedBulletRotationOffset: this.rangedBulletRotationOffset,
            rangedBulletSpawnOffsetX: this.rangedBulletSpawnOffsetX,
            rangedBulletSpawnOffsetY: this.rangedBulletSpawnOffsetY,
            movement: this.movement ? this.movement.snapshot() : null,
            ui: this.ui ? this.ui.snapshot() : null,
            combat: this.combat ? this.combat.snapshot() : null,
            animation: this.animation ? this.animation.snapshot() : null,
            ranged: this.ranged ? this.ranged.snapshot() : null,
        };
    }
}
