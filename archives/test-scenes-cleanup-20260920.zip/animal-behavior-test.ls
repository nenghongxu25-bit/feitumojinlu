{
  "_$ver": 1,
  "_$id": "animaltestscene",
  "_$type": "Scene",
  "name": "AnimalBehaviorTest",
  "width": 1334,
  "height": 750,
  "_$comp": [
    {
      "_$type": "13e0a173-96e7-4ef9-9291-135944a71204",
      "scriptPath": "../src/Animals/AnimalDemo.ts",
      "wolfNode": {
        "_$ref": "animalwolf"
      },
      "boarNode": {
        "_$ref": "animalboar"
      },
      "targetNode": {
        "_$ref": "animaltesttarget"
      },
      "obstacleNode": {
        "_$ref": "animaltestfence"
      },
      "autoTest": true
    }
  ],
  "_$child": [
    {
      "_$id": "animalwolf",
      "_$type": "Sprite",
      "name": "Wolf",
      "x": 680,
      "y": 420,
      "width": 0,
      "height": 0,
      "_$comp": [
        {
          "_$type": "053362f0-cfdd-4d3d-90af-c1953215b367",
          "scriptPath": "../src/Animals/AnimalFrameAnimator.ts",
          "viewNode": {
            "_$ref": "animalwolfview"
          },
          "walkFrames": [
            {
              "_$uuid": "28e2aa47-f520-4a52-bfd5-ebbedb136fb6",
              "_$type": "Texture"
            },
            {
              "_$uuid": "c7bf63b3-80f5-4444-92f9-e9a76aebf535",
              "_$type": "Texture"
            },
            {
              "_$uuid": "914bf606-21d3-47a0-b629-07330788962e",
              "_$type": "Texture"
            },
            {
              "_$uuid": "fdbda641-23b9-4dfa-b00a-2d8f76dd2f4f",
              "_$type": "Texture"
            },
            {
              "_$uuid": "e385714b-ef0e-4a94-8a6e-5eb70bee8baa",
              "_$type": "Texture"
            },
            {
              "_$uuid": "17441428-bf58-4fae-bafa-aee51810faed",
              "_$type": "Texture"
            },
            {
              "_$uuid": "f75847db-873b-41f4-bca7-1cb950238320",
              "_$type": "Texture"
            },
            {
              "_$uuid": "a082310e-3cb4-4ad8-bcd3-58109c72ea66",
              "_$type": "Texture"
            }
          ],
          "runFrames": [
            {
              "_$uuid": "1a391d63-91ba-4b46-8da6-3f51141857d9",
              "_$type": "Texture"
            },
            {
              "_$uuid": "ca8e799f-9dbd-42f0-9232-88732cb4171c",
              "_$type": "Texture"
            },
            {
              "_$uuid": "256ae6ca-8581-4779-bad5-3cb50a8b5214",
              "_$type": "Texture"
            },
            {
              "_$uuid": "af329b98-35bf-4108-aa96-488150588f64",
              "_$type": "Texture"
            },
            {
              "_$uuid": "10c244c0-f6ea-4b0a-8668-85f2c6b666d4",
              "_$type": "Texture"
            },
            {
              "_$uuid": "779ad00a-21a5-4d89-9b52-cb60775849da",
              "_$type": "Texture"
            },
            {
              "_$uuid": "7d568831-0a4c-4d7d-8c8e-ed3142205230",
              "_$type": "Texture"
            },
            {
              "_$uuid": "1ca0c447-6670-4180-a171-cf9997fc8123",
              "_$type": "Texture"
            }
          ],
          "attackFrames": [
            {
              "_$uuid": "a8def699-5f2f-4366-adee-2cf752be483d",
              "_$type": "Texture"
            },
            {
              "_$uuid": "010d7c6d-7aa5-4f76-9150-2e7434e0c8d4",
              "_$type": "Texture"
            },
            {
              "_$uuid": "a33f90a8-98b6-4742-af3b-2da08bae99eb",
              "_$type": "Texture"
            },
            {
              "_$uuid": "9c75b656-f3cf-4949-bd5f-369f6674c69f",
              "_$type": "Texture"
            },
            {
              "_$uuid": "71dbaf4e-d0e7-4daa-bb16-8fc63eb8e769",
              "_$type": "Texture"
            },
            {
              "_$uuid": "6d76d975-27c8-49cd-9630-735c794f71e0",
              "_$type": "Texture"
            }
          ],
          "walkFps": 8,
          "runFps": 12,
          "attackFps": 10
        },
        {
          "_$type": "b09fc0ce-6350-4e19-a112-79421e795417",
          "scriptPath": "../src/Animals/AnimalController.ts",
          "targetNode": {
            "_$ref": "animaltesttarget"
          },
          "hitBodyNode": {
            "_$ref": "animalwolfbody"
          },
          "aggressive": true,
          "maxHp": 80,
          "walkSpeed": 38,
          "runSpeed": 130,
          "aggroDistance": 280,
          "loseAggroDistance": 430,
          "leashDistance": 520,
          "patrolRadius": 100,
          "idleSeconds": 1.8,
          "attackDistance": 65,
          "attackPower": 8,
          "attackCooldown": 1.1,
          "attackHitFrame": 3,
          "collisionHalfWidth": 24,
          "deathFadeSeconds": 1
        },
        {
          "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
          "scriptPath": "../src/systems/DepthSortable.ts",
          "groundY": 0,
          "blendDistance": 0
        }
      ],
      "_$child": [
        {
          "_$id": "animalwolfview",
          "_$type": "Sprite",
          "name": "AnimalView",
          "width": 224,
          "height": 224,
          "anchorX": 0.5,
          "anchorY": 0.9464285714285714,
          "texture": {
            "_$uuid": "28e2aa47-f520-4a52-bfd5-ebbedb136fb6",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "animalwolfbody",
          "_$type": "Sprite",
          "name": "HitBody",
          "x": -48,
          "y": -88,
          "width": 96,
          "height": 88,
          "_$comp": [
            {
              "_$id": "0aob",
              "_$type": "RigidBody",
              "type": "kinematic",
              "applyOwnerColliderComponent": false,
              "shapes": [
                {
                  "_$type": "BoxShape2D",
                  "x": 0,
                  "y": 0,
                  "density": 1,
                  "restitution": 0,
                  "restitutionThreshold": 1,
                  "friction": 0,
                  "isSensor": true,
                  "width": 96,
                  "height": 88
                }
              ],
              "gravityScale": 0
            }
          ]
        }
      ]
    },
    {
      "_$id": "animalboar",
      "_$type": "Sprite",
      "name": "YoungBoar",
      "x": 420,
      "y": 600,
      "width": 0,
      "height": 0,
      "_$comp": [
        {
          "_$type": "053362f0-cfdd-4d3d-90af-c1953215b367",
          "scriptPath": "../src/Animals/AnimalFrameAnimator.ts",
          "viewNode": {
            "_$ref": "animalboarview"
          },
          "walkFrames": [
            {
              "_$uuid": "cce83db9-9b28-4e4e-8ec7-8769828a876d",
              "_$type": "Texture"
            },
            {
              "_$uuid": "c96244fe-586b-40a0-9578-7e5298dbd120",
              "_$type": "Texture"
            },
            {
              "_$uuid": "70e655a5-52ed-4ed4-806d-6c5d06c73cda",
              "_$type": "Texture"
            },
            {
              "_$uuid": "96148064-1c79-4bcf-9493-d0bab0450bbf",
              "_$type": "Texture"
            },
            {
              "_$uuid": "966df816-d1d8-4dca-9a23-082d0b832623",
              "_$type": "Texture"
            },
            {
              "_$uuid": "2661a593-7397-4465-ba97-43c194e06593",
              "_$type": "Texture"
            },
            {
              "_$uuid": "17d0ee52-b295-4340-8360-a58dc41f66ad",
              "_$type": "Texture"
            },
            {
              "_$uuid": "9fc00e82-bbfa-4a7c-a25f-ce949fe5681c",
              "_$type": "Texture"
            }
          ],
          "runFrames": [
            {
              "_$uuid": "33d8157f-41aa-42dc-8ec9-980fe5e7f76c",
              "_$type": "Texture"
            },
            {
              "_$uuid": "f61412d5-a804-4d42-901e-f24de8b3048d",
              "_$type": "Texture"
            },
            {
              "_$uuid": "ed65d242-c5d7-41b2-aa6c-780535658197",
              "_$type": "Texture"
            },
            {
              "_$uuid": "7c32a487-f722-416d-a75d-68bc075a4c66",
              "_$type": "Texture"
            },
            {
              "_$uuid": "8c43a895-52ab-45be-b6dd-23312d04c293",
              "_$type": "Texture"
            },
            {
              "_$uuid": "a0912dbc-7a88-4261-bb46-99be70bc6763",
              "_$type": "Texture"
            },
            {
              "_$uuid": "741efd0c-2ca1-4f68-b06a-66ba108c41be",
              "_$type": "Texture"
            },
            {
              "_$uuid": "795fa964-f340-4878-8307-377f8e4a2437",
              "_$type": "Texture"
            }
          ],
          "attackFrames": [
            {
              "_$uuid": "4e0bd637-803d-4efb-ad88-8d3a780c2c88",
              "_$type": "Texture"
            },
            {
              "_$uuid": "5b4b640f-b677-4807-8c63-9ee6bc5e7c34",
              "_$type": "Texture"
            },
            {
              "_$uuid": "749496ff-105d-4a3b-9ec1-6ac1f2d5c4ce",
              "_$type": "Texture"
            },
            {
              "_$uuid": "f80b4f5a-490a-482b-a22a-65ce8a0dd714",
              "_$type": "Texture"
            },
            {
              "_$uuid": "cd15cd1e-33b7-4c07-aed3-a0bd09046d18",
              "_$type": "Texture"
            },
            {
              "_$uuid": "3f2e862c-4f81-4649-9735-33fcd403a704",
              "_$type": "Texture"
            }
          ],
          "walkFps": 8,
          "runFps": 12,
          "attackFps": 10
        },
        {
          "_$type": "b09fc0ce-6350-4e19-a112-79421e795417",
          "scriptPath": "../src/Animals/AnimalController.ts",
          "targetNode": {
            "_$ref": "animaltesttarget"
          },
          "hitBodyNode": {
            "_$ref": "animalboarbody"
          },
          "aggressive": false,
          "maxHp": 45,
          "walkSpeed": 28,
          "runSpeed": 95,
          "aggroDistance": 280,
          "loseAggroDistance": 430,
          "leashDistance": 520,
          "patrolRadius": 70,
          "idleSeconds": 1.8,
          "attackDistance": 50,
          "attackPower": 5,
          "attackCooldown": 1.3,
          "attackHitFrame": 3,
          "collisionHalfWidth": 18,
          "deathFadeSeconds": 1
        },
        {
          "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
          "scriptPath": "../src/systems/DepthSortable.ts",
          "groundY": 0,
          "blendDistance": 0
        }
      ],
      "_$child": [
        {
          "_$id": "animalboarview",
          "_$type": "Sprite",
          "name": "AnimalView",
          "width": 160,
          "height": 160,
          "anchorX": 0.5,
          "anchorY": 0.925,
          "texture": {
            "_$uuid": "cce83db9-9b28-4e4e-8ec7-8769828a876d",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "animalboarbody",
          "_$type": "Sprite",
          "name": "HitBody",
          "x": -32,
          "y": -58,
          "width": 64,
          "height": 58,
          "_$comp": [
            {
              "_$id": "diyp",
              "_$type": "RigidBody",
              "type": "kinematic",
              "applyOwnerColliderComponent": false,
              "shapes": [
                {
                  "_$type": "BoxShape2D",
                  "x": 0,
                  "y": 0,
                  "density": 1,
                  "restitution": 0,
                  "restitutionThreshold": 1,
                  "friction": 0,
                  "isSensor": true,
                  "width": 64,
                  "height": 58
                }
              ],
              "gravityScale": 0
            }
          ]
        }
      ]
    },
    {
      "_$id": "animaltesttarget",
      "_$type": "Sprite",
      "name": "TestTarget_NoSave",
      "x": 450,
      "y": 420,
      "width": 0,
      "height": 0,
      "_$comp": [
        {
          "_$type": "13e0a173-96e7-4ef9-9291-135944a71203",
          "scriptPath": "../src/Animals/AnimalTestTarget.ts"
        },
        {
          "_$type": "85c8cc94-c77e-4333-b4cb-83803c909a33",
          "scriptPath": "../src/combat/AttackHitbox.ts",
          "attackerNode": {
            "_$ref": "animaltesttarget"
          },
          "targetKind": "enemy"
        },
        {
          "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
          "scriptPath": "../src/systems/DepthSortable.ts",
          "groundY": 0,
          "blendDistance": 0
        }
      ],
      "_$child": [
        {
          "_$id": "animaltesttargetimage",
          "_$type": "Sprite",
          "name": "TargetImage",
          "x": -146,
          "y": 178,
          "width": 126,
          "height": 128,
          "anchorX": 0.5,
          "anchorY": 0.921875,
          "scaleX": 0.65,
          "scaleY": 0.65,
          "texture": {
            "_$uuid": "c189dc46-6429-4d68-ac17-9a42e4536338",
            "_$type": "Texture"
          }
        }
      ]
    },
    {
      "_$id": "animaltestfence",
      "_$type": "Sprite",
      "name": "ObstacleFence",
      "x": 870,
      "y": 480,
      "width": 0,
      "height": 0,
      "_$comp": [
        {
          "_$type": "20c26d35-af30-488e-9ed0-20b58656a0cb",
          "scriptPath": "../src/systems/DepthObstacle.ts",
          "blockX": 0,
          "blockY": 0,
          "blockWidth": 180,
          "blockHeight": 32,
          "stowCrossingWeapon": false
        },
        {
          "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
          "scriptPath": "../src/systems/DepthSortable.ts",
          "groundY": 0,
          "blendDistance": 0
        }
      ],
      "_$child": [
        {
          "_$id": "animaltestfenceimage",
          "_$type": "Sprite",
          "name": "FenceImage",
          "y": -112,
          "width": 256,
          "height": 171,
          "scaleX": 0.7,
          "scaleY": 0.7,
          "texture": {
            "_$uuid": "0de7a0a9-45fa-4cc9-bf80-ca05f07eebf1",
            "_$type": "Texture"
          }
        }
      ]
    }
  ]
}