{
  "_$ver": 1,
  "_$id": "forestIsoStudy",
  "_$type": "Scene",
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "name": "ForestRainPreview",
  "width": 1334,
  "height": 750,
  "_$comp": [
    {
      "_$type": "86fb35d4-bffe-4012-bc9f-85f003b0b723",
      "scriptPath": "../src/systems/IsometricStudyBackdrop.ts"
    }
  ],
  "_$child": [
    {
      "_$id": "b8c2002fd002",
      "_$type": "Sprite",
      "name": "SoilFoundation",
      "x": 155,
      "y": 95,
      "width": 1024,
      "height": 562,
      "texture": {
        "_$uuid": "aabb3941-df85-49eb-aba9-9853b2f2aba4",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "forestIsoView",
      "_$type": "Sprite",
      "name": "NativeIsometricGround",
      "x": 91,
      "y": 95,
      "width": 0,
      "height": 0,
      "_$child": [
        {
          "_$id": "forestIsoTiles",
          "_$type": "Sprite",
          "name": "ForestDiamondTiles_8x8",
          "width": 0,
          "height": 0,
          "_$comp": [
            {
              "_$type": "TileMapLayer",
              "layer": 0,
              "tileSet": {
                "_$uuid": "5889eb93-13f3-4dcc-8f73-5a27909be63f",
                "_$type": "TileSet"
              },
              "chunkDatas": {
                "0": {
                  "0": {
                    "_$type": "TileMapChunkData",
                    "chunkX": 0,
                    "chunkY": 0,
                    "compressData": {
                      "0": [
                        230,
                        229
                      ],
                      "1": [
                        263
                      ],
                      "5": [
                        388
                      ],
                      "6": [
                        261,
                        292,
                        324
                      ],
                      "7": [
                        294,
                        293,
                        326,
                        325,
                        357,
                        356,
                        389,
                        420
                      ],
                      "10": [
                        130,
                        161,
                        193,
                        224
                      ],
                      "12": [
                        355,
                        419
                      ],
                      "13": [
                        452
                      ],
                      "17": [
                        262
                      ],
                      "21": [
                        199,
                        198
                      ],
                      "26": [
                        197,
                        228
                      ],
                      "27": [
                        260,
                        291,
                        323,
                        354
                      ],
                      "28": [
                        4,
                        231,
                        35,
                        67,
                        98,
                        387
                      ],
                      "35": [
                        69
                      ],
                      "36": [
                        134,
                        133
                      ],
                      "39": [
                        68
                      ],
                      "40": [
                        100
                      ],
                      "43": [
                        36
                      ],
                      "44": [
                        99,
                        131
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "4": 0,
                      "35": 0,
                      "36": 0,
                      "67": 0,
                      "68": 0,
                      "69": 0,
                      "98": 0,
                      "99": 0,
                      "100": 0,
                      "130": 0,
                      "131": 0,
                      "133": 0,
                      "134": 0,
                      "161": 0,
                      "193": 0,
                      "197": 0,
                      "198": 0,
                      "199": 0,
                      "224": 0,
                      "228": 0,
                      "229": 0,
                      "230": 0,
                      "231": 0,
                      "260": 0,
                      "261": 0,
                      "262": 0,
                      "263": 0,
                      "291": 0,
                      "292": 0,
                      "293": 0,
                      "294": 0,
                      "323": 0,
                      "324": 0,
                      "325": 0,
                      "326": 0,
                      "354": 0,
                      "355": 0,
                      "356": 0,
                      "357": 0,
                      "387": 0,
                      "388": 0,
                      "389": 0,
                      "419": 0,
                      "420": 0,
                      "452": 0,
                      "_$type": "Record"
                    }
                  },
                  "_$type": "Record"
                },
                "_$type": "Record"
              }
            }
          ]
        }
      ]
    },
    {
      "_$id": "groundrainpreview",
      "_$type": "Sprite",
      "name": "GroundRainPreview",
      "x": -2587,
      "y": -1561,
      "width": 7680,
      "height": 6784,
      "alpha": 0,
      "texture": {
        "_$uuid": "f3344eba-8afb-41ad-b3d3-0bccb5bfc37e",
        "_$type": "Texture"
      },
      "_mouseState": 1,
      "_$comp": [
        {
          "_$type": "cb292bea-fca6-4503-8c06-db76efaac944",
          "scriptPath": "../src/systems/GroundRain.ts",
          "wetness": 1,
          "autoAccumulate": false,
          "accumulationSeconds": 18,
          "rainIntensity": 1,
          "puddleSize": 150,
          "edgeFeather": 1,
          "groundNode": {
            "_$ref": "forestIsoTiles"
          },
          "playerNode": null,
          "footOffsetY": 80,
          "stepDistance": 72,
          "footRipples": false
        }
      ]
    },
    {
      "_$id": "0630ba6976b9",
      "_$type": "Sprite",
      "name": "ContactShadows",
      "width": 0,
      "height": 0,
      "_$child": [
        {
          "_$id": "05de2694ea8d",
          "_$type": "Sprite",
          "name": "ContactShadow1",
          "x": 554,
          "y": 185,
          "width": 84,
          "height": 22,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "47b4f259a498",
          "_$type": "Sprite",
          "name": "ContactShadow2",
          "x": 435,
          "y": 239,
          "width": 94,
          "height": 22,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "1c304a2078e0",
          "_$type": "Sprite",
          "name": "ContactShadow3",
          "x": 1041,
          "y": 345,
          "width": 83,
          "height": 22,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "79668a30d68c",
          "_$type": "Sprite",
          "name": "ContactShadow4",
          "x": 511,
          "y": 505,
          "width": 66,
          "height": 22,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "a23150ffd2a3",
          "_$type": "Sprite",
          "name": "ContactShadow5",
          "x": 491,
          "y": 204,
          "width": 52,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "d2a188fc1f6d",
          "_$type": "Sprite",
          "name": "ContactShadow6",
          "x": 906,
          "y": 263,
          "width": 47,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "1e05b87e9746",
          "_$type": "Sprite",
          "name": "ContactShadow7",
          "x": 495,
          "y": 479,
          "width": 44,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "f8fa933f2752",
          "_$type": "Sprite",
          "name": "ContactShadow8",
          "x": 799,
          "y": 339,
          "width": 50,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "9c0a9a7617e3",
          "_$type": "Sprite",
          "name": "ContactShadow9",
          "x": 711,
          "y": 395,
          "width": 38,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "3ceb83328ca2",
          "_$type": "Sprite",
          "name": "ContactShadow10",
          "x": 597,
          "y": 454,
          "width": 44,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "0d34058a4f23",
          "_$type": "Sprite",
          "name": "ContactShadow11",
          "x": 577,
          "y": 291,
          "width": 47,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        },
        {
          "_$id": "b36e64cfeb44",
          "_$type": "Sprite",
          "name": "ContactShadow12",
          "x": 378,
          "y": 339,
          "width": 77,
          "height": 14,
          "alpha": 0.24,
          "texture": {
            "_$uuid": "56ad4f56-850e-4430-b8b9-a59c2ccc5368",
            "_$type": "Texture"
          }
        }
      ]
    },
    {
      "_$id": "c1545241e0c2",
      "_$type": "Sprite",
      "name": "ForestProps",
      "width": 0,
      "height": 0,
      "_$child": [
        {
          "_$id": "4a4912f8bdeb",
          "_$type": "Sprite",
          "name": "pine0",
          "x": 534,
          "y": 14,
          "width": 112,
          "height": 177,
          "texture": {
            "_$uuid": "fd40b293-e4cf-48bb-8dad-39153833012c",
            "_$type": "Texture"
          },
          "zIndex": 191
        },
        {
          "_$id": "8558dc8f5994",
          "_$type": "Sprite",
          "name": "shrub4",
          "x": 479,
          "y": 151,
          "width": 69,
          "height": 59,
          "texture": {
            "_$uuid": "aead6b2d-9829-41ce-b711-20f80bbcda33",
            "_$type": "Texture"
          },
          "zIndex": 210
        },
        {
          "_$id": "8db813e2269d",
          "_$type": "Sprite",
          "name": "pine1",
          "x": 413,
          "y": 50,
          "width": 125,
          "height": 195,
          "texture": {
            "_$uuid": "fd40b293-e4cf-48bb-8dad-39153833012c",
            "_$type": "Texture"
          },
          "zIndex": 245
        },
        {
          "_$id": "a8d5fa074aa2",
          "_$type": "Sprite",
          "name": "shrub5",
          "x": 895,
          "y": 215,
          "width": 63,
          "height": 54,
          "texture": {
            "_$uuid": "aead6b2d-9829-41ce-b711-20f80bbcda33",
            "_$type": "Texture"
          },
          "zIndex": 269
        },
        {
          "_$id": "b5ded66d7a1a",
          "_$type": "Sprite",
          "name": "rocks10",
          "x": 566,
          "y": 235,
          "width": 62,
          "height": 62,
          "texture": {
            "_$uuid": "0eda0cc4-5877-4b07-86cb-f798f89ae9f4",
            "_$type": "Texture"
          },
          "zIndex": 297
        },
        {
          "_$id": "c357cfe4ce0e",
          "_$type": "Sprite",
          "name": "rocks7",
          "x": 788,
          "y": 279,
          "width": 66,
          "height": 66,
          "texture": {
            "_$uuid": "0eda0cc4-5877-4b07-86cb-f798f89ae9f4",
            "_$type": "Texture"
          },
          "zIndex": 345
        },
        {
          "_$id": "36a84685e4c0",
          "_$type": "Sprite",
          "name": "log11",
          "x": 360,
          "y": 291,
          "width": 102,
          "height": 54,
          "texture": {
            "_$uuid": "32c98b15-5115-4cd2-b6b6-c53466d44492",
            "_$type": "Texture"
          },
          "zIndex": 345
        },
        {
          "_$id": "0e71fc6af7a5",
          "_$type": "Sprite",
          "name": "pine2",
          "x": 1022,
          "y": 177,
          "width": 110,
          "height": 174,
          "texture": {
            "_$uuid": "fd40b293-e4cf-48bb-8dad-39153833012c",
            "_$type": "Texture"
          },
          "zIndex": 351
        },
        {
          "_$id": "73ae544e22bc",
          "_$type": "Sprite",
          "name": "rocks8",
          "x": 702,
          "y": 350,
          "width": 51,
          "height": 51,
          "texture": {
            "_$uuid": "0eda0cc4-5877-4b07-86cb-f798f89ae9f4",
            "_$type": "Texture"
          },
          "zIndex": 401
        },
        {
          "_$id": "d450bd5fb64f",
          "_$type": "Sprite",
          "name": "rocks9",
          "x": 586,
          "y": 401,
          "width": 59,
          "height": 59,
          "texture": {
            "_$uuid": "0eda0cc4-5877-4b07-86cb-f798f89ae9f4",
            "_$type": "Texture"
          },
          "zIndex": 460
        },
        {
          "_$id": "c9a6b5bed6cc",
          "_$type": "Sprite",
          "name": "shrub6",
          "x": 484,
          "y": 435,
          "width": 58,
          "height": 50,
          "texture": {
            "_$uuid": "aead6b2d-9829-41ce-b711-20f80bbcda33",
            "_$type": "Texture"
          },
          "zIndex": 485
        },
        {
          "_$id": "8017388786ef",
          "_$type": "Sprite",
          "name": "pine3",
          "x": 495,
          "y": 372,
          "width": 88,
          "height": 139,
          "texture": {
            "_$uuid": "fd40b293-e4cf-48bb-8dad-39153833012c",
            "_$type": "Texture"
          },
          "zIndex": 511
        }
      ]
    },
    {
      "_$id": "ykgeg25s",
      "_$type": "Sprite",
      "name": "Sprite",
      "x": 696,
      "y": 343,
      "width": 100,
      "height": 100,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "5889eb93-13f3-4dcc-8f73-5a27909be63f",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "_$type": "Record"
                },
                "transFlags": {
                  "_$type": "Record"
                }
              },
              "_$type": "Record",
              "-1": {
                "_$type": "TileMapChunkData",
                "chunkX": -1,
                "chunkY": 0,
                "compressData": {
                  "1": [
                    220
                  ],
                  "2": [
                    252
                  ],
                  "3": [
                    285
                  ],
                  "4": [
                    317
                  ],
                  "5": [
                    219,
                    350
                  ],
                  "6": [
                    251
                  ],
                  "7": [
                    284
                  ],
                  "8": [
                    316
                  ],
                  "9": [
                    349
                  ],
                  "10": [
                    250,
                    381
                  ],
                  "11": [
                    283
                  ],
                  "12": [
                    315
                  ],
                  "13": [
                    348
                  ],
                  "14": [
                    380
                  ],
                  "15": [
                    413
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "219": 0,
                  "220": 0,
                  "250": 0,
                  "251": 0,
                  "252": 0,
                  "283": 0,
                  "284": 0,
                  "285": 0,
                  "315": 0,
                  "316": 0,
                  "317": 0,
                  "348": 0,
                  "349": 0,
                  "350": 0,
                  "380": 0,
                  "381": 0,
                  "413": 0,
                  "_$type": "Record"
                }
              }
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "screenweatherarea",
      "_$type": "Area2D",
      "name": "ScreenWeatherArea",
      "width": 1334,
      "height": 750,
      "_mouseState": 1,
      "_$child": [
        {
          "_$id": "3ipkjcv8",
          "_$prefab": "f5375f43-a7d4-4609-a63d-3b23ede2d79f",
          "name": "WeatherLayer",
          "active": true,
          "x": 667,
          "y": 375,
          "scaleX": 1,
          "scaleY": 1,
          "visible": true,
          "_$comp": [
            {
              "_$type": "e312cb13-7d08-4e8c-bf9a-72512691e032",
              "scriptPath": "../src/Player/ScreenWeatherEmitter.ts",
              "margin": 96
            }
          ],
          "_$child": [
            {
              "_$override": "k7dyz6ys",
              "x": 0,
              "y": 0,
              "active": true,
              "_$comp": [
                {
                  "_$override": "ShurikenParticle2DRenderer",
                  "particleSystem": {
                    "main": {
                      "simulationSpace": 0,
                      "scaleMode": 0
                    },
                    "shape": {
                      "_$type": "Shape2DModule",
                      "shape": {
                        "_$type": "Box2DShape",
                        "size": {
                          "_$type": "Vector2",
                          "x": 37,
                          "y": 26
                        }
                      }
                    }
                  }
                }
              ]
            },
            {
              "_$override": "9j5lht6u",
              "active": false,
              "name": "snow",
              "x": 0,
              "y": 0,
              "_$comp": [
                {
                  "_$override": "ShurikenParticle2DRenderer",
                  "sharedMaterial": {
                    "_$uuid": "9e6cf127-512a-4e15-b7f6-02ef6e48ab93",
                    "_$type": "Material"
                  },
                  "particleSystem": {
                    "main": {
                      "simulationSpace": 0,
                      "scaleMode": 0,
                      "startSizeX": {
                        "_$type": "ParticleMinMaxCurve",
                        "mode": 2,
                        "constantMin": 0.2,
                        "constantMax": 0.4,
                        "curveMin": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        },
                        "curveMax": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        }
                      },
                      "startSizeY": {
                        "_$type": "ParticleMinMaxCurve",
                        "mode": 2,
                        "constantMin": 0.2,
                        "constantMax": 0.4,
                        "curveMin": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        },
                        "curveMax": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        }
                      }
                    },
                    "textureSheetAnimation": {
                      "_$type": "TextureSheetAnimationModule",
                      "tiles": {
                        "_$type": "Vector2",
                        "x": 4,
                        "y": 4
                      },
                      "rowIndex": null,
                      "frame": {
                        "_$type": "ParticleMinMaxCurve",
                        "curveMin": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        },
                        "curveMax": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              1,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        }
                      },
                      "startFrame": {
                        "_$type": "ParticleMinMaxCurve",
                        "mode": 2,
                        "constantMax": 15,
                        "curveMin": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        },
                        "curveMax": {
                          "_$type": "GradientDataNumber",
                          "_elements": {
                            "_$type": "Float32Array",
                            "value": [
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0,
                              0
                            ]
                          },
                          "_currentLength": 0
                        }
                      }
                    },
                    "shape": {
                      "_$type": "Shape2DModule",
                      "shape": {
                        "_$type": "Box2DShape",
                        "size": {
                          "_$type": "Vector2",
                          "x": 37,
                          "y": 26
                        }
                      }
                    }
                  }
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}