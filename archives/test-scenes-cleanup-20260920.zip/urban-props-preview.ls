{
  "_$ver": 1,
  "_$id": "20fc8cf66408",
  "_$type": "Scene",
  "name": "UrbanPropsV2",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$child": [
    {
      "_$id": "bd0f71c3a373",
      "_$type": "Sprite",
      "name": "shop-shelf",
      "x": 25,
      "y": 25,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "572b4d89-85bd-40ad-acd5-1b0733d1749d",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "84ea89514209",
      "_$type": "Sprite",
      "name": "checkout-counter",
      "x": 355,
      "y": 25,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "c8bde0d3-0bd5-4391-83fb-54f1ee4990be",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "a899ab09251f",
      "_$type": "Sprite",
      "name": "office-desk",
      "x": 685,
      "y": 25,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "893935fe-7a01-43a9-b811-6f16a59b9b91",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "52dddb459af1",
      "_$type": "Sprite",
      "name": "filing-cabinet",
      "x": 1015,
      "y": 25,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "c69c72a0-cf33-4caa-9653-318a8ba5a3ea",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "6572e9013de9",
      "_$type": "Sprite",
      "name": "staff-locker",
      "x": 25,
      "y": 395,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "e4b1af26-7a99-400b-a258-92920122fe47",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "e33e5cb9fd52",
      "_$type": "Sprite",
      "name": "waiting-sofa",
      "x": 355,
      "y": 395,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "03fc89b6-1be0-4b6b-b614-013b70df5285",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "f9a6a774ee77",
      "_$type": "Sprite",
      "name": "vending-machine",
      "x": 685,
      "y": 395,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "e17cd80a-7090-422b-96b2-8cb25039a398",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "72e1cd9963b2",
      "_$type": "Sprite",
      "name": "mechanic-tool-cart",
      "x": 1015,
      "y": 395,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.22328548644338117,
      "scaleY": 0.22328548644338117,
      "texture": {
        "_$uuid": "9e8f99a8-438a-4bd7-b9b4-ad49c9031e61",
        "_$type": "Texture"
      }
    }
  ]
}