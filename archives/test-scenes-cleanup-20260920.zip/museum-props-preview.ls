{
  "_$ver": 1,
  "_$id": "5132d70eaa0e",
  "_$type": "Scene",
  "name": "MuseumPropsV1",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$child": [
    {
      "_$id": "a1a74982617d",
      "_$type": "Sprite",
      "name": "glass-display-case",
      "x": 65,
      "y": 20,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "9c78a4e3-c06c-4820-b558-09e7e7bf6fb2",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "a764d064c61c",
      "_$type": "Sprite",
      "name": "table-display-case",
      "x": 505,
      "y": 20,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "217d5728-18bf-4d2c-95b3-4d487598584d",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "4cdd8f216c9d",
      "_$type": "Sprite",
      "name": "artifact-pedestal",
      "x": 945,
      "y": 20,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "6cf4a30c-22c9-47df-9e06-cad1bbdc49cb",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "8bc427e4c200",
      "_$type": "Sprite",
      "name": "round-display-plinth",
      "x": 65,
      "y": 390,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "743dc928-1316-4c22-b091-3155f915f584",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "a6ffc508da28",
      "_$type": "Sprite",
      "name": "exhibit-table",
      "x": 505,
      "y": 390,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "5ae4d613-74a5-4e32-9abe-949da7360fb5",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "723c982eec4c",
      "_$type": "Sprite",
      "name": "museum-info-stand",
      "x": 945,
      "y": 390,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.23923444976076555,
      "scaleY": 0.23923444976076555,
      "texture": {
        "_$uuid": "0b5f51f4-2f12-4e46-a429-4d4075188778",
        "_$type": "Texture"
      }
    }
  ]
}