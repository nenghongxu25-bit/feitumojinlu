{
  "_$ver": 1,
  "_$id": "1d0682612b2a",
  "_$type": "Scene",
  "name": "UrbanElementsPreview",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$child": [
    {
      "_$id": "ce220b4a441a",
      "_$type": "Sprite",
      "name": "streets-corner-store",
      "x": 20,
      "y": 48,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "93424695-5645-4b4a-a6f8-7ac4007deb30",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "97e8fe3a4d72",
      "_$type": "Sprite",
      "name": "streets-apartment",
      "x": 282,
      "y": 48,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "347acaec-a0ba-48e0-95fc-69526be0e192",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "6ede109cb79b",
      "_$type": "Sprite",
      "name": "streets-bus-shelter",
      "x": 544,
      "y": 48,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "53fbdb93-0580-44fc-8a1c-b40676d6c6c0",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "bea652b7f62c",
      "_$type": "Sprite",
      "name": "streets-dumpster",
      "x": 806,
      "y": 48,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "77be34f6-01f0-48fe-8138-b25653f2b0af",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "98537267f391",
      "_$type": "Sprite",
      "name": "streets-delivery-van",
      "x": 1068,
      "y": 48,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "08777caf-fd33-4c1e-a741-619456375263",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "1aad5938cf73",
      "_$type": "Sprite",
      "name": "center-office-entry",
      "x": 20,
      "y": 410,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "223a3ea1-e3c3-468a-a24c-9b97a205d73b",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "8280885396d1",
      "_$type": "Sprite",
      "name": "center-parking-entry",
      "x": 282,
      "y": 410,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "6fda81d2-a588-49bf-a6aa-9b4534666898",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "418a88b53a7d",
      "_$type": "Sprite",
      "name": "center-security-barrier",
      "x": 544,
      "y": 410,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "ed800135-3906-43e6-b951-8e2b09ce668c",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "7d0b92ac6dd5",
      "_$type": "Sprite",
      "name": "center-planter-bench",
      "x": 806,
      "y": 410,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "6f16491b-fa0f-4796-91e8-0f4d32fae7f8",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "f8c2f1201496",
      "_$type": "Sprite",
      "name": "center-utility-cabinet",
      "x": 1068,
      "y": 410,
      "width": 1254,
      "height": 1254,
      "scaleX": 0.19138755980861244,
      "scaleY": 0.19138755980861244,
      "texture": {
        "_$uuid": "2fde2247-c215-419d-85ec-3b843aadfbf8",
        "_$type": "Texture"
      }
    }
  ]
}