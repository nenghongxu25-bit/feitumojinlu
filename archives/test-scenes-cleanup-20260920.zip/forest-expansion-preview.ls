{
  "_$ver": 1,
  "_$id": "expansionScene",
  "_$type": "Scene",
  "name": "ForestExpansionComplete",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$comp": [
    {
      "_$type": "86fb35d4-bffe-4012-bc9f-85f003b0b723",
      "scriptPath": "../src/systems/IsometricStudyBackdrop.ts"
    }
  ],
  "_$child": [
    {
      "_$id": "expansion0",
      "_$type": "Sprite",
      "name": "forest-crooked-pine-v1",
      "x": 128.66666666666666,
      "y": 20,
      "width": 186.66666666666669,
      "height": 280,
      "texture": {
        "_$uuid": "ce5a1396-064b-460a-a400-d4c5e7debf99",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion1",
      "_$type": "Sprite",
      "name": "forest-dead-tree-v1",
      "x": 560.3013698630137,
      "y": 20,
      "width": 187.3972602739726,
      "height": 280,
      "texture": {
        "_$uuid": "787452e0-b3d1-4ed1-9889-7602a05a596f",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion2",
      "_$type": "Sprite",
      "name": "forest-young-pine-v1",
      "x": 992.6666666666666,
      "y": 20,
      "width": 186.66666666666669,
      "height": 280,
      "texture": {
        "_$uuid": "b153feb3-f016-46a4-b727-1a65b0743f98",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion3",
      "_$type": "Sprite",
      "name": "forest-sparse-shrub-v1",
      "x": 99.6606334841629,
      "y": 320,
      "width": 244.6787330316742,
      "height": 190,
      "texture": {
        "_$uuid": "53113d90-85ef-4542-a7dd-052004119cec",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion4",
      "_$type": "Sprite",
      "name": "forest-needle-leaf-litter-v1",
      "x": 511.5,
      "y": 320,
      "width": 285.00000000000006,
      "height": 190.00000000000003,
      "texture": {
        "_$uuid": "b9ab68d0-22f4-4c44-b04f-cbb47199a12a",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion5",
      "_$type": "Sprite",
      "name": "forest-broken-branches-v1",
      "x": 943.5,
      "y": 320,
      "width": 285.00000000000006,
      "height": 190.00000000000003,
      "texture": {
        "_$uuid": "e2b4e9df-df6a-4b11-8bf2-1053190fb536",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion6",
      "_$type": "Sprite",
      "name": "forest-bank-reeds-v1",
      "x": 116.29352396972246,
      "y": 545,
      "width": 211.41295206055509,
      "height": 190,
      "texture": {
        "_$uuid": "98824960-e70c-4154-a969-d848423f7215",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion7",
      "_$type": "Sprite",
      "name": "forest-muddy-bank-v1",
      "x": 511.5,
      "y": 545,
      "width": 285.00000000000006,
      "height": 190.00000000000003,
      "texture": {
        "_$uuid": "9edc253c-2109-4bce-83ca-a9000313d2ff",
        "_$type": "Texture"
      }
    },
    {
      "_$id": "expansion8",
      "_$type": "Sprite",
      "name": "forest-rock-cliff-v1",
      "width": 360,
      "height": 180,
      "texture": {
        "_$uuid": "c6b84dc4-d8ea-4f62-8ae3-11f2343b8027",
        "_$type": "Texture"
      },
      "x": 906,
      "y": 555
    }
  ]
}