{
  "_$ver": 1,
  "_$id": "a72c52015963",
  "_$type": "Scene",
  "name": "ForestCliffTilesPreview",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$comp": [
    {
      "_$type": "86fb35d4-bffe-4012-bc9f-85f003b0b723"
    }
  ],
  "_$child": [
    {
      "_$id": "611bdfab0025",
      "_$type": "Sprite",
      "name": "ExistingForestGrass",
      "x": 275,
      "y": 90,
      "scaleX": 0.875,
      "scaleY": 0.875,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "cf4f935b-bf97-46e0-bceb-7111f80648f9",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "10": [
                    0,
                    1,
                    2,
                    3,
                    4,
                    5,
                    6
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "1": 0,
                  "2": 0,
                  "3": 0,
                  "4": 0,
                  "5": 0,
                  "6": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "366d9d6271a4",
      "_$type": "Sprite",
      "name": "WideWall_7x3",
      "x": 275,
      "y": 190,
      "scaleX": 0.2679425837320574,
      "scaleY": 0.2679425837320574,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "0": [
                    0
                  ],
                  "1": [
                    1,
                    2,
                    3,
                    4,
                    5
                  ],
                  "2": [
                    6
                  ],
                  "3": [
                    32
                  ],
                  "4": [
                    33,
                    34,
                    35,
                    36,
                    37
                  ],
                  "5": [
                    38
                  ],
                  "6": [
                    64
                  ],
                  "7": [
                    65,
                    66,
                    67,
                    68,
                    69
                  ],
                  "8": [
                    70
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "1": 0,
                  "2": 8,
                  "3": 0,
                  "4": 8,
                  "5": 0,
                  "6": 0,
                  "32": 0,
                  "33": 0,
                  "34": 8,
                  "35": 0,
                  "36": 8,
                  "37": 0,
                  "38": 0,
                  "64": 0,
                  "65": 0,
                  "66": 8,
                  "67": 0,
                  "68": 8,
                  "69": 0,
                  "70": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "39630a9621ff",
      "_$type": "Sprite",
      "name": "TallWall_3x5",
      "x": 48,
      "y": 205,
      "scaleX": 0.14354066985645933,
      "scaleY": 0.14354066985645933,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "0": [
                    0
                  ],
                  "1": [
                    1
                  ],
                  "2": [
                    2
                  ],
                  "3": [
                    32,
                    64,
                    96
                  ],
                  "4": [
                    33,
                    65,
                    97
                  ],
                  "5": [
                    34,
                    66,
                    98
                  ],
                  "6": [
                    128
                  ],
                  "7": [
                    129
                  ],
                  "8": [
                    130
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "1": 0,
                  "2": 0,
                  "32": 0,
                  "33": 0,
                  "34": 0,
                  "64": 16,
                  "65": 16,
                  "66": 16,
                  "96": 0,
                  "97": 0,
                  "98": 0,
                  "128": 0,
                  "129": 0,
                  "130": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "48b8fe7c708f",
      "_$type": "Sprite",
      "name": "Tile_0",
      "x": 145,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "0": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "31cdae0799d2",
      "_$type": "Sprite",
      "name": "Tile_1",
      "x": 261,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "1": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "468dd3d1d126",
      "_$type": "Sprite",
      "name": "Tile_2",
      "x": 377,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "2": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "936ebd362d05",
      "_$type": "Sprite",
      "name": "Tile_3",
      "x": 493,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "3": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "5082d1013888",
      "_$type": "Sprite",
      "name": "Tile_4",
      "x": 609,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "4": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "25980016a016",
      "_$type": "Sprite",
      "name": "Tile_5",
      "x": 725,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "5": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "c18681a6b2db",
      "_$type": "Sprite",
      "name": "Tile_6",
      "x": 841,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "6": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "1123ffed3be5",
      "_$type": "Sprite",
      "name": "Tile_7",
      "x": 957,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "7": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    },
    {
      "_$id": "8f6d63f6479c",
      "_$type": "Sprite",
      "name": "Tile_8",
      "x": 1073,
      "y": 588,
      "scaleX": 0.22009569377990432,
      "scaleY": 0.22009569377990432,
      "_$comp": [
        {
          "_$type": "TileMapLayer",
          "layer": 0,
          "tileSet": {
            "_$uuid": "eb9cbd07-90dc-4c30-b1e3-519775022a25",
            "_$type": "TileSet"
          },
          "chunkDatas": {
            "0": {
              "0": {
                "_$type": "TileMapChunkData",
                "chunkX": 0,
                "chunkY": 0,
                "compressData": {
                  "8": [
                    0
                  ],
                  "_$type": "Record"
                },
                "transFlags": {
                  "0": 0,
                  "_$type": "Record"
                }
              },
              "_$type": "Record"
            },
            "_$type": "Record"
          }
        }
      ]
    }
  ]
}
