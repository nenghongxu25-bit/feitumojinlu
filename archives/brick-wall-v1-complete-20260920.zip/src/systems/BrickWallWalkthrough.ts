import { TileBlockMovement } from './TileBlockMovement';
import { DepthObstacle } from './DepthObstacle';
const { regClass } = Laya;

/** Keyboard movement in the single wall kit sample, using the game's movement collision. */
@regClass('f46d1f31-2b7f-4f2f-88bb-64a6e40a1f51')
export class BrickWallWalkthrough extends Laya.Script {
    private move = new TileBlockMovement();
    private keys = new Set<string>();
    private down = (e: any) => this.keys.add(String(e.key || '').toLowerCase());
    private up = (e: any) => { this.keys.delete(String(e.key || '').toLowerCase()); const a=this.owner as Laya.Sprite;console.info(`[BrickWallWalkthrough] position ${a.x.toFixed(1)},${a.y.toFixed(1)}`); };
    onEnable(): void { Laya.stage.on(Laya.Event.KEY_DOWN,this,this.down); Laya.stage.on(Laya.Event.KEY_UP,this,this.up); }
    onDisable(): void { Laya.stage.off(Laya.Event.KEY_DOWN,this,this.down); Laya.stage.off(Laya.Event.KEY_UP,this,this.up);this.keys.clear(); }
    onStart(): void { Laya.timer.once(300,this,this.verify); }
    onDestroy(): void { Laya.timer.clearAll(this); }
    private verify(): void {
        const actor=this.owner as Laya.Sprite;
        const count=Array.from(DepthObstacle.activeObstacles).filter(o=>o.owner.scene===actor.scene).length;
        console.info(`[BrickWallWalkthrough] Ready: ${count} wall footprints; WASD / arrow keys.`);
        const p=(u:number,v:number)=>({x:64+64*(u-v),y:32+32*(u+v)});
        const test=(a:{x:number;y:number},b:{x:number;y:number})=>DepthObstacle.blocksMove(actor,a.x,a.y,b.x,b.y,0,12);
        const wall=test(p(5,3),p(7,3)),corner=test(p(-.5,-.5),p(.5,.5)),entry=test(p(3.5,7),p(3.5,5));
        console.info(`[BrickWallWalkthrough] collision checks: wall=${wall}, corner=${corner}, entrance=${entry}; expected true,true,false.`);
    }
    onUpdate(): void {
        const x=Number(this.keys.has('d')||this.keys.has('arrowright'))-Number(this.keys.has('a')||this.keys.has('arrowleft'));
        const y=Number(this.keys.has('s')||this.keys.has('arrowdown'))-Number(this.keys.has('w')||this.keys.has('arrowup'));
        if(!x&&!y)return;
        const step=180*Math.min(Laya.timer.delta/1000,.05)/Math.hypot(x,y);
        this.move.move(this.owner as Laya.Sprite,x*step,y*step,{footOffsetY:0,halfWidth:12});
    }
}
