{
  "_$ver": 1,
  "_$id": "brickwallsample",
  "_$type": "Scene",
  "name": "BrickWallSampleReady",
  "width": 1334,
  "height": 750,
  "left": 0,
  "right": 0,
  "top": 0,
  "bottom": 0,
  "_$comp": [
    {
      "_$type": "86fb35d4-bffe-4012-bc9f-85f003b0b723"
    }
  ],
  "_$child": [
    {
      "_$id": "brickworld",
      "_$type": "Sprite",
      "name": "ActorLayer",
      "x": 640,
      "y": 280,
      "_$child": [
        {
          "_$id": "7a874a38f884",
          "_$type": "Sprite",
          "name": "BrickWallLayer",
          "_$comp": [
            {
              "_$type": "TileMapLayer",
              "tileSet": {
                "_$uuid": "045e4ac5-bdbc-4d01-a4fa-1a374b73cec6",
                "_$type": "TileSet"
              },
              "chunkDatas": {
                "0": {
                  "0": {
                    "_$type": "TileMapChunkData",
                    "chunkX": 0,
                    "chunkY": 0,
                    "compressData": {
                      "3": [
                        0
                      ],
                      "5": [
                        32,
                        65,
                        97,
                        130,
                        162
                      ],
                      "6": [
                        195
                      ],
                      "10": [
                        226,
                        258,
                        289,
                        321,
                        352
                      ],
                      "12": [
                        384
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "0": 0,
                      "32": 0,
                      "65": 0,
                      "97": 0,
                      "130": 0,
                      "162": 0,
                      "195": 0,
                      "226": 0,
                      "258": 0,
                      "289": 0,
                      "321": 0,
                      "352": 0,
                      "384": 0,
                      "_$type": "Record"
                    }
                  },
                  "_$type": "Record",
                  "-1": {
                    "_$type": "TileMapChunkData",
                    "chunkX": -1,
                    "chunkY": 0,
                    "compressData": {
                      "1": [
                        383
                      ],
                      "4": [
                        286
                      ],
                      "5": [
                        253
                      ],
                      "9": [
                        221
                      ],
                      "10": [
                        63,
                        95,
                        126,
                        158,
                        189
                      ],
                      "_$type": "Record"
                    },
                    "transFlags": {
                      "63": 0,
                      "95": 0,
                      "126": 0,
                      "158": 0,
                      "189": 0,
                      "221": 0,
                      "253": 0,
                      "286": 0,
                      "383": 0,
                      "_$type": "Record"
                    }
                  }
                },
                "_$type": "Record"
              }
            },
            {
              "_$type": "818f8acf-a35f-42d4-b285-b2d8b67d5af8",
              "scriptPath": "../../../src/systems/BrickWallTileLayer.ts"
            }
          ]
        },
        {
          "_$id": "brickactor",
          "_$type": "Sprite",
          "name": "WalkHere",
          "x": -96,
          "y": 416,
          "_$comp": [
            {
              "_$type": "1806c38c-ebc3-45d1-a8a0-322ed94be4cb",
              "groundY": 0
            },
            {
              "_$type": "f46d1f31-2b7f-4f2f-88bb-64a6e40a1f51"
            }
          ],
          "_$child": [
            {
              "_$id": "b1t7v9q2",
              "_$type": "Sprite",
              "name": "viewnode",
              "width": 0,
              "height": 0,
              "anchorX": 0.5,
              "anchorY": 0.5,
              "_$comp": [
                {
                  "_$type": "Spine2DRenderNode",
                  "layer": 0,
                  "useFastRender": false,
                  "source": "res://f87ec402-9dd0-4a49-90f0-2352581455dc",
                  "skinName": "player_normal",
                  "animationName": "idle/idle_ranged_firearm",
                  "externalSkins": [
                    {
                      "_$type": "ExternalSkin"
                    }
                  ],
                  "offset": {
                    "_$type": "Vector2",
                    "x": -80,
                    "y": -120
                  },
                  "premultipliedAlpha": true
                }
              ],
              "y": -80
            }
          ]
        }
      ]
    }
  ]
}