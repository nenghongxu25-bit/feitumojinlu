const fs=require('fs'),assert=require('node:assert/strict'),vm=require('vm'),ts=require('typescript');
const dir='assets/tileset/brick-wall-v1',set=JSON.parse(fs.readFileSync(dir+'/brick-wall.tres','utf8')),layout=JSON.parse(fs.readFileSync(dir+'/layout.json','utf8'));
const g=set.groups[0],png=fs.readFileSync(dir+'/brick-wall-atlas.png');
assert.equal(png.readUInt32BE(16),g.atlasSize.x);assert.equal(png.readUInt32BE(20),g.atlasSize.y);
// Laya's actual column/row formula: excludes leading margin, includes trailing separation.
assert.equal(Math.floor((g.atlasSize.x-g.margin.x)/(g.textureRegionSize.x+g.separation.x)),4);
assert.equal(Math.floor((g.atlasSize.y-g.margin.y)/(g.textureRegionSize.y+g.separation.y)),4);
for(let y=0;y<4;y++)for(let x=0;x<4;x++){const t=g.tiles[y][x];assert.equal(t.localPos.x,x);assert.equal(t.localPos.y,y);assert.equal(t.tileDatas[0].texture_origin.y,g.textureRegionSize.y/2-layout.pivot[1]);}
const context={exports:{}};vm.runInNewContext(ts.transpileModule(fs.readFileSync('src/systems/BrickWallGeometry.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2019}}).outputText,context);
const {wallFootprints,wallGroundAtX}=context.exports;
assert.equal(wallFootprints(0)[0][2],.25,'wall thickness doubled to one quarter of a grid unit');
assert.equal(wallFootprints(0)[0][3],.25,'both diagonal directions have the same thickness');
for(let mask=0;mask<16;mask++){
 const boxes=wallFootprints(mask);assert.ok(boxes.length>=1);assert.ok(wallGroundAtX(mask,0)!==null);
 for(const [u,v,w,h]of boxes){assert.ok(u>=-.5&&v>=-.5&&u+w<=.5&&v+h<=.5);}
 for(let bit=0;bit<4;bit++){
  const endpoints=[[.5,0],[0,.5],[-.5,0],[0,-.5]],p=endpoints[bit];
  const hit=boxes.some(([u,v,w,h])=>p[0]>=u&&p[0]<=u+w&&p[1]>=v&&p[1]<=v+h);
  assert.equal(hit,!!(mask&(1<<bit)),'correct open and joined ends');
 }
}
assert.equal(layout.cells.length,22);assert.equal(new Set(layout.cells.map(c=>c.x+','+c.y)).size,22);
console.log('PASS: atlas stride/GIDs, all 16 mask interfaces, ground extents, tile pivots and 22 sample cells.');
