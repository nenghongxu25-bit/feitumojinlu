Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
public static class BrickWallBaker {
 const int W=128, T=384, H=256;
 static Bitmap source;
 static double Frac(double n){return n-Math.Floor(n);}
 static Color Tex(double u,double z,double light) {
  // A mirrored repeat keeps both ends identical, even if the generated material is imperfect.
  double phase=Frac(u); double q=phase<.5?phase*2:(1-phase)*2;
  int sx=122+(int)(q*480),sy=Math.Max(0,Math.Min(source.Height-1,(int)((1-z/H)*(source.Height-1))));
  Color c=source.GetPixel(sx,sy);
  return Color.FromArgb(255,Math.Min(255,(int)(c.R*light)),Math.Min(255,(int)(c.G*light)),Math.Min(255,(int)(c.B*light)));
 }
 static bool Occupied(int mask,int i,int j){
  bool a=i>=6&&i<=9,b=j>=6&&j<=9;
  return (a&&b)||((mask&1)!=0&&b&&i>=8)||((mask&2)!=0&&a&&j>=8)||((mask&4)!=0&&b&&i<=7)||((mask&8)!=0&&a&&j<=7);
 }
 static Color Sample(int mask,double x,double y){
  double u0=x/128+y/64,v0=-x/128+y/64,best=-1;int face=0;double bu=0,bv=0;
  for(int i=0;i<16;i++)for(int j=0;j<16;j++){
   if(!Occupied(mask,i,j))continue;
   double ulo=(i-8)/16.0,uhi=(i-7)/16.0,vlo=(j-8)/16.0,vhi=(j-7)/16.0;
   double enter=Math.Max(0,Math.Max((ulo-u0)*64,(vlo-v0)*64));
   double leave=Math.Min(H,Math.Min((uhi-u0)*64,(vhi-v0)*64));
   if(enter>=leave||leave<=best)continue;
   best=leave;bu=u0+best/64;bv=v0+best/64;
   face=best>=H-1e-8?0:((uhi-u0)*64<(vhi-v0)*64?1:2);
  }
  if(best<0)return Color.Transparent;
  if(face==0){Color c=Tex(bu-bv,H-5,1.16);return c;}
  return Tex(face==1?bv:bu,best,face==1?.74:1.0);
 }
 public static void Run(string folder){
  source=new Bitmap(Path.Combine(folder,"brick-material-source.png"));
  using(Bitmap atlas=new Bitmap(532,1556,PixelFormat.Format32bppArgb)){
   for(int mask=0;mask<16;mask++){
    int ox=2+(mask%4)*132,oy=2+(mask/4)*388;
    for(int y=0;y<T;y++)for(int x=0;x<W;x++){
     int r=0,g=0,b=0,n=0;
     for(int sy=0;sy<2;sy++)for(int sx=0;sx<2;sx++){
      Color c=Sample(mask,x+(sx+.5)/2-64,y+(sy+.5)/2-336);
      if(c.A>0){r+=c.R;g+=c.G;b+=c.B;n++;}
     }
     if(n>0)atlas.SetPixel(ox+x,oy+y,Color.FromArgb(n*255/4,r/n,g/n,b/n));
    }
   }
   atlas.Save(Path.Combine(folder,"brick-wall-atlas.png"),ImageFormat.Png);
  }
  source.Dispose();
 }
}
'@
[BrickWallBaker]::Run((Join-Path (Get-Location) 'assets/tileset/brick-wall-v1'))
